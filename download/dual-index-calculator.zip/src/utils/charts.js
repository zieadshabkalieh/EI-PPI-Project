// ─── src/utils/charts.js ───

// Helper to pick a color based on “EI‐style” numerical score:
export function getEIColor(score) {
  if (score >= 85) return '#006400'; // Dark Green
  if (score >= 70) return '#5cb85c'; // Green
  if (score >= 55) return '#f0ad4e'; // Yellow
  return '#d9534f';                  // Red
}

export function getPracticalityColor(score) {
  if (score >= 75)      return 'darkblue';   // 🔵 Excellent Practicality
  else if (score >= 50) return 'lightblue';  // 🔷 Acceptable Practicality
  else                   return 'magenta';    // 🟣 Impractical
}
// A tiny horizontal progress‐bar helper:
export function createHorizontalProgressBar(score, maxScore, color, label) {
  const progressContainer = document.createElement('div');
  progressContainer.className = 'horizontal-progress-container';
  progressContainer.style.width = '100%';
  progressContainer.style.marginBottom = '15px';

  const labelDiv = document.createElement('div');
  labelDiv.className = 'progress-label';
  labelDiv.style.display = 'flex';
  labelDiv.style.justifyContent = 'space-between';
  labelDiv.style.marginBottom = '5px';

  const nameSpan = document.createElement('span');
  nameSpan.textContent = label;
  nameSpan.style.fontWeight = 'bold';

  const valueSpan = document.createElement('span');
  valueSpan.textContent = score.toFixed(1);
  valueSpan.style.color = color;
  valueSpan.style.fontWeight = 'bold';

  labelDiv.appendChild(nameSpan);
  labelDiv.appendChild(valueSpan);
  progressContainer.appendChild(labelDiv);

  const progressBar = document.createElement('div');
  progressBar.className = 'progress-bar-bg';
  progressBar.style.height = '10px';
  progressBar.style.width = '100%';
  progressBar.style.backgroundColor = '#e6e6e6';
  progressBar.style.borderRadius = '5px';
  progressBar.style.overflow = 'hidden';

  const progressFill = document.createElement('div');
  progressFill.className = 'progress-bar-fill';
  progressFill.style.height = '100%';
  progressFill.style.width = `${(score / maxScore) * 100}%`;
  progressFill.style.backgroundColor = color;
  progressFill.style.borderRadius = '5px';

  progressBar.appendChild(progressFill);
  progressContainer.appendChild(progressBar);

  return progressContainer;
}

// The “coxcomb” or polar‐area chart function, unmodified:
export function createCoxcombChart(dataPoints) {
  const container = document.createElement('div');
  container.className = 'coxcomb-chart-container';
  container.style.position = 'relative';

  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('width', '100%');
  svg.setAttribute('height', '100%');
  svg.setAttribute('viewBox', '0 0 380 380');

  const centerX = 190;
  const centerY = 190;
  const maxRadius = 100;

//   // Background rings at 25/50/75/100
// Background rings at 25/50/75/100
[25, 50, 75, 100].forEach(level => {
  const r = (level / 100) * maxRadius;
  const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  circle.setAttribute('cx', centerX);
  circle.setAttribute('cy', centerY);
  circle.setAttribute('r', r);
  circle.setAttribute('stroke', '#e0e0e0');
  circle.setAttribute('stroke-width', '1');
  circle.setAttribute('fill', 'none');
  svg.appendChild(circle);

  const levelLabel = document.createElementNS('http://www.w3.org/2000/svg', 'text');
  levelLabel.setAttribute('x', centerX + 4);
  levelLabel.setAttribute('y', centerY - r + 12);
  levelLabel.setAttribute('font-size', '9');
  levelLabel.setAttribute('fill', '#999999');
  levelLabel.textContent = level;
  svg.appendChild(levelLabel);
});


  const numSlices = dataPoints.length;
  const angleStep = (2 * Math.PI) / numSlices;

  dataPoints.forEach((pt, i) => {
    const valueNormalized = pt.value / 100;
    const radius = valueNormalized * maxRadius;
    const startAngle = angleStep * i - Math.PI / 2;
    const endAngle = startAngle + angleStep;

    // Outer‐edge points
    const x1 = centerX + Math.cos(startAngle) * radius;
    const y1 = centerY + Math.sin(startAngle) * radius;
    const x2 = centerX + Math.cos(endAngle) * radius;
    const y2 = centerY + Math.sin(endAngle) * radius;

    // Draw the slice:
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    const d = [
      `M ${centerX} ${centerY}`,
      `L ${x1.toFixed(2)} ${y1.toFixed(2)}`,
      `A ${radius.toFixed(2)} ${radius.toFixed(2)} 0 0 1 ${x2.toFixed(2)} ${y2.toFixed(2)}`,
      `Z`
    ].join(' ');
    path.setAttribute('d', d);
    path.setAttribute('fill', pt.color);
    path.setAttribute('stroke', '#ffffff');
    path.setAttribute('stroke-width', '1');
    svg.appendChild(path);

    // Dot at slice tip:
    const dotR = 6;
    const tipX = centerX + Math.cos((startAngle + endAngle) / 2) * radius;
    const tipY = centerY + Math.sin((startAngle + endAngle) / 2) * radius;
    const dot = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    dot.setAttribute('cx', tipX.toFixed(2));
    dot.setAttribute('cy', tipY.toFixed(2));
    dot.setAttribute('r', dotR);
    dot.setAttribute('fill', '#ffffff');
    dot.setAttribute('stroke', pt.color);
    dot.setAttribute('stroke-width', '3');
    svg.appendChild(dot);

    // Numeric score just outside the tip:
    const labelDistance = radius + 24;
    const midAngle = (startAngle + endAngle) / 2;
    const scoreX = centerX + Math.cos(midAngle) * labelDistance;
    const scoreY = centerY + Math.sin(midAngle) * labelDistance;
    const scoreText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    scoreText.setAttribute('x', scoreX.toFixed(2));
    scoreText.setAttribute('y', scoreY.toFixed(2));
    scoreText.setAttribute('text-anchor', 'middle');
    scoreText.setAttribute('font-size', '12');
    scoreText.setAttribute('font-weight', '700');
    scoreText.setAttribute('fill', pt.color);
    scoreText.textContent = pt.value.toFixed(1);
    svg.appendChild(scoreText);

    // Category name farther out:
    const nameDistance = radius + 50;
    const nameX = centerX + Math.cos(midAngle) * nameDistance;
    const nameY = centerY + Math.sin(midAngle) * nameDistance;
    const nameText = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    nameText.setAttribute('x', nameX.toFixed(2));
    nameText.setAttribute('y', nameY.toFixed(2));
    nameText.setAttribute('text-anchor', 'middle');
    nameText.setAttribute('font-size', '13');
    nameText.setAttribute('font-weight', '600');
    nameText.setAttribute('fill', '#333333');
    nameText.textContent = pt.name;
    svg.appendChild(nameText);
  });

  // Tiny center circle:
  const centerCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  centerCircle.setAttribute('cx', centerX);
  centerCircle.setAttribute('cy', centerY);
  centerCircle.setAttribute('r', maxRadius * 0.15);
  centerCircle.setAttribute('fill', '#fafafa');
  centerCircle.setAttribute('stroke', 'none');
  svg.appendChild(centerCircle);

  container.appendChild(svg);
  return container;
}
