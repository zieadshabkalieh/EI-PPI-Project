import { translate } from '../../utils/i18n.js';
import { calculateWasteScore } from '../../utils/calculations.js';
import {
  getEIColor,
  getPracticalityColor,
  createHorizontalProgressBar,
  createCoxcombChart
} from '../../utils/charts.js';

// ─── add this helper exactly as in SamplePreparationForm ───
function makeCollapsible(headerEl, contentEl) {
  headerEl.style.cursor = 'pointer';
  contentEl.style.display = 'none';
  headerEl.addEventListener('click', () => {
    contentEl.style.display = contentEl.style.display === 'none' ? '' : 'none';
  });
}

export function WasteForm(state, onChange, scores) {
  const form = document.createElement('div');
  form.className = 'form-section card waste-card';
  form.style.position = 'relative';
  
  const title = document.createElement('h3');
  title.textContent = translate('Waste');
  form.appendChild(title);
  
  // Info card with detailed explanation (collapsed by default)
  const infoCard = document.createElement('div');
  infoCard.className = 'info-card info-card-waste';

  const infoCardTitle = document.createElement('div');
  infoCardTitle.className = 'info-card-title collapsible-title';
  infoCardTitle.textContent = translate('About Waste Management');
  infoCard.appendChild(infoCardTitle);

  const infoCardContent = document.createElement('div');
  infoCardContent.className = 'info-card-content';
  infoCardContent.innerHTML = `
    <p>${translate('This page helps you calculate the Waste Score for your analytical method. The score assesses the environmental impact of waste generation, encouraging minimal waste production and proper waste management.')}</p>
    <p>${translate('Please fill in the information below to calculate your Waste Score.')}</p>
    <p><strong>${translate('Biodegradable vs. Non-biodegradable Waste')}</strong></p>
    <ul>
      <li>${translate('Biodegradable waste includes materials that can be broken down by natural processes, such as aqueous solutions, some organic solvents, and naturally derived compounds.')}</li>
      <li>${translate('Non-biodegradable waste includes materials that persist in the environment, such as halogenated solvents, heavy metals, and many synthetic compounds.')}</li>
    </ul>
    <p><strong>${translate('Waste Treatment Options')}</strong></p>
    <ul>
      <li>${translate('No treatment: Waste is disposed of without any treatment')}</li>
      <li>${translate('Treatment with reuse: Waste is treated and reused in the analytical process, reducing the overall environmental impact')}</li>
    </ul>
  `;
  infoCard.appendChild(infoCardContent);

  // Hide the content until the title is clicked:
  makeCollapsible(infoCardTitle, infoCardContent);

  form.appendChild(infoCard);

  
  // Waste volume section
  const wasteVolumeSection = document.createElement('div');
  wasteVolumeSection.className = 'form-section waste-volume-section';
  
  // Amount of waste per sample
  const volumeGroup = createFormGroup(
    translate('Amount of Waste per Sample'),
    'volume',
    [
      { value: 'less1',          label: translate('< 1 mL (g)'),     score: '100' },
      { value: 'between1And10',  label: translate('1-10 mL (g)'),    score: '90' },
      { value: 'between10And100',label: translate('11-100 mL (g)'), score: '60' },
      { value: 'more100',        label: translate('> 100 mL (g)'),   score: '35' }
    ],
    state.volume,
    (value) => onChange('volume', value)
  );
  volumeGroup.classList.add('waste-section');
  wasteVolumeSection.appendChild(volumeGroup);
  form.appendChild(wasteVolumeSection);
  
  // Biodegradability section
  const biodegradabilitySection = document.createElement('div');
  biodegradabilitySection.className = 'form-section biodegradability-section';
  
  // Biodegradability - converted to radio group for consistent UI
  const biodegradableGroup = createFormGroup(
    translate('Waste Biodegradability'),
    'biodegradable',
    [
      { value: 'yes', label: translate('Biodegradable waste'), score: '+10' },
      { value: 'no',  label: translate('Non-biodegradable waste'), score: '-10' }
    ],
    state.biodegradable ? 'yes' : 'no',
    (value) => onChange('biodegradable', value === 'yes')
  );
  biodegradableGroup.classList.add('waste-section');
  biodegradabilitySection.appendChild(biodegradableGroup);
  form.appendChild(biodegradabilitySection);
  
  // Treatment section
  const treatmentSection = document.createElement('div');
  treatmentSection.className = 'form-section treatment-section';
  
  // Treatment
  const treatmentGroup = createFormGroup(
    translate('Treatment'),
    'treatment',
    [
      { value: 'none',  label: translate('No treatment applied'), score: '-5'  },
      { value: 'less10',label: translate('Treatment with reuse < 10 mL (g)'), score: '+10' },
      { value: 'more10',label: translate('Treatment with reuse > 10 mL (g)'), score: '+20' }
    ],
    state.treatment,
    (value) => onChange('treatment', value)
  );
  treatmentGroup.classList.add('waste-section');
  treatmentSection.appendChild(treatmentGroup);
  form.appendChild(treatmentSection);
   // ─── COMPUTE WASTE SCORE ───
  const currentWasteScore = calculateWasteScore(state);

  // ─── PINNED HORIZONTAL PROGRESS BAR ───
  const wasteProgressBar = createHorizontalProgressBar(
    currentWasteScore,              // score
    100,                            // max
    getEIColor(currentWasteScore),  // color
    translate('Waste Score')
  );
  // Ensure the form container is relatively positioned:
  form.style.position = 'relative';
  wasteProgressBar.style.position = 'absolute';
  wasteProgressBar.style.top = '20px';
  wasteProgressBar.style.right = '20px';
  wasteProgressBar.style.width = '180px';
  form.appendChild(wasteProgressBar);

  // ─── BUILD FIVE‐SLICE RADAR DATA ───
  // `scores` object contains { samplePrep, instrumentation, reagent, waste, practicality }
  const radarData = [];
  if (scores.samplePrep !== undefined) {
    radarData.push({
      name: translate('Sample Prep'),
      value: scores.samplePrep,
      color: getEIColor(scores.samplePrep)
    });
  }
  if (scores.instrumentation !== undefined) {
    radarData.push({
      name: translate('Instrumentation'),
      value: scores.instrumentation,
      color: getEIColor(scores.instrumentation)
    });
  }
  // Use this page’s own Waste score
  radarData.push({
    name: translate('Waste'),
    value: currentWasteScore,
    color: getEIColor(currentWasteScore)
  });
  if (scores.reagent !== undefined) {
    radarData.push({
      name: translate('Reagent'),
      value: scores.reagent,
      color: getEIColor(scores.reagent)
    });
  }
  // Practicality always last
  if (scores.practicality !== undefined) {
    radarData.push({
      name: translate('Practicality'),
      value: scores.practicality,
      color: getPracticalityColor(scores.practicality)
    });
  }

  // ─── REMOVE OLD CHART & APPEND NEW COXCOMB ───
  const oldChart = document.getElementById('coxcombChart');
  if (oldChart) oldChart.remove();

  const coxcombChart = createCoxcombChart(radarData);
  coxcombChart.id = 'coxcombChart';
  coxcombChart.style.position = 'fixed';
  coxcombChart.style.top = '200px';
  coxcombChart.style.right = '10px';
  coxcombChart.style.width = '25vw';
  coxcombChart.style.height = 'auto';
  coxcombChart.style.zIndex = '999';
  coxcombChart.style.pointerEvents = 'none';
  document.body.appendChild(coxcombChart);

  // Shift page content left so the chart doesn’t overlap:
  document.body.style.marginRight = '25vw';
  return form;
}

function createFormGroup(label, name, options, selectedValue, onChange) {
  const group = document.createElement('div');
  group.className = 'form-group';
  
  const groupLabel = document.createElement('label');
  groupLabel.textContent = label;
  groupLabel.htmlFor = name;
  groupLabel.style.fontSize = '1.2rem';
  groupLabel.style.fontWeight = '600';
  groupLabel.style.marginBottom = '15px';
  groupLabel.style.display = 'block';
  group.appendChild(groupLabel);
  
  options.forEach((option) => {
    const radioContainer = document.createElement('label');
    radioContainer.className = 'custom-radio-container';
    radioContainer.htmlFor = `${name}_${option.value}`;
    
    // Create actual radio input (hidden)
    const radio = document.createElement('input');
    radio.className = 'custom-radio-input';
    radio.type = 'radio';
    radio.id = `${name}_${option.value}`;
    radio.name = name;
    radio.value = option.value;
    radio.checked = selectedValue === option.value;
    radio.addEventListener('change', () => onChange(option.value));
    
    // Create custom radio visual element
    const radioCheckmark = document.createElement('span');
    radioCheckmark.className = 'radio-checkmark';
    
    // Create label text
    const labelText = document.createTextNode(option.label);
    
    // Create score display
    const scoreSpan = document.createElement('span');
    scoreSpan.className = 'option-score';
    scoreSpan.textContent = option.score;
    
    // Append all elements
    radioContainer.appendChild(radio);
    radioContainer.appendChild(radioCheckmark);
    radioContainer.appendChild(labelText);
    radioContainer.appendChild(scoreSpan);
    
    // Add waste-option class for styling
    radioContainer.classList.add('waste-option');
    
    group.appendChild(radioContainer);
  });
  
  return group;
}
