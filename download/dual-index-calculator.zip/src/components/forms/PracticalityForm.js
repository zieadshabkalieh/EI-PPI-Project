import { translate } from '../../utils/i18n.js';
import { calculatePracticalityScore } from '../../utils/calculations.js';   // ← add this
import {
  getEIColor,
  getPracticalityColor,   // ← add this
  createHorizontalProgressBar,
  createCoxcombChart
} from '../../utils/charts.js';
// ─── add this helper exactly as in SamplePreparationForm ───
function makeCollapsible(headerEl, contentEl) {
  headerEl.style.cursor = 'pointer';
  contentEl.style.display = 'none';
  headerEl.addEventListener('click', () => {
    contentEl.style.display = contentEl.style.display === 'none' ? '' : 'none';
  });
}

export function PracticalityForm(state, onChange, scores) {
  const form = document.createElement('div');
  form.className = 'form-section card practicality-card';
  
  const title = document.createElement('h3');
  title.textContent = translate('Practicality Index');
  form.appendChild(title);
  
   // Info card with detailed explanation (collapsed by default)
  const infoCard = document.createElement('div');
  infoCard.className = 'info-card info-card-practicality';

  const infoCardTitle = document.createElement('div');
  infoCardTitle.className = 'info-card-title collapsible-title';
  infoCardTitle.textContent = translate('About Practicality Index');
  infoCard.appendChild(infoCardTitle);

  const infoCardContent = document.createElement('div');
  infoCardContent.className = 'info-card-content';
  infoCardContent.innerHTML = `
    <p>${translate('The Practicality Index (PI) accounts for 50% of the total Dual Index score. It measures the real-world applicability and efficiency of an analytical method.')}</p>
    <p>${translate('Please fill in the information below to calculate your Practicality Index (PI).')}</p>
  `;
  infoCard.appendChild(infoCardContent);

  // Hide content until the title is clicked:
  makeCollapsible(infoCardTitle, infoCardContent);

  form.appendChild(infoCard);

  
  // Method Characteristics Section
  const methodSection = document.createElement('div');
  methodSection.className = 'form-section method-characteristics-section';
  
  // 1. Nature of Method
  const natureGroup = createFormGroup(
    translate('Nature of Method'),
    'natureOfMethod',
    [
      { value: 'quantitative', label: translate('Quantitative'), score: '10' },
      { value: 'semiquantitative', label: translate('Semiquantitative'), score: '6' },
      { value: 'qualitative', label: translate('Qualitative'), score: '4' }
    ],
    state.natureOfMethod || 'quantitative',
    (value) => onChange('natureOfMethod', value)
  );
  natureGroup.classList.add('practicality-option');
  methodSection.appendChild(natureGroup);
  
  // 2. QbD Applied (using designOfExperiment field)
  const designGroup = createFormGroup(
    translate('QbD Applied'),
    'designOfExperiment',
    [
      { value: 'factorial', label: translate('Optimization'), score: '10' },
      { value: 'partial', label: translate('Screening'), score: '5' },
      { value: 'none', label: translate('No Design'), score: '0' }
    ],
    state.designOfExperiment || 'factorial',
    (value) => onChange('designOfExperiment', value)
  );
  designGroup.classList.add('practicality-option');
  methodSection.appendChild(designGroup);
  form.appendChild(methodSection);
  
    // ─── 3. AI Integration ───
  const aiSection = document.createElement('div');
  aiSection.className = 'form-section ai-integration-section';

  const aiGroup = createFormGroup(
    translate('AI Integration'),
    'aiIntegration',
    [
      { value: 'advanced', label: translate('Advanced AI Integration'),  score: '10' },
      { value: 'moderate', label: translate('Moderate AI Integration'),  score: '7'  },
      { value: 'basic',    label: translate('Basic AI Integration'),     score: '3'  },
      { value: 'none',     label: translate('No AI Integration'),        score: '0'  }
    ],
    state.aiIntegration || 'none',
    (value) => onChange('aiIntegration', value)
  );
  aiGroup.classList.add('practicality-option');
  aiSection.appendChild(aiGroup);
  form.appendChild(aiSection);

  // Validation Section
  const validationSection = document.createElement('div');
  validationSection.className = 'form-section validation-section';
  
  // 3. Validation
  const validationGroup = createFormGroup(
    translate('Validation'),
    'validation',
    [
      { value: 'full', label: translate('Fully Validated'), score: '10' },
      { value: 'partial', label: translate('Partial'), score: '5' },
      { value: 'none', label: translate('Not validated'), score: '0' }
    ],
    state.validation || 'full',
    (value) => onChange('validation', value)
  );
  validationGroup.classList.add('practicality-option');
  validationSection.appendChild(validationGroup);
  
  // 4. Sensitivity
  const sensitivityGroup = createFormGroup(
    translate('Sensitivity'),
    'sensitivity',
    [
      { value: 'picogram', label: translate('Picogram'), score: '10' },
      { value: 'nanogram', label: translate('Nanogram'), score: '8' },
      { value: 'microgram', label: translate('Microgram'), score: '5' },
      { value: 'more', label: translate('>Microgram'), score: '2' }
    ],
    state.sensitivity || 'picogram',
    (value) => onChange('sensitivity', value)
  );
  sensitivityGroup.classList.add('practicality-option');
  validationSection.appendChild(sensitivityGroup);
  form.appendChild(validationSection);
  
  // ─── 6. Availability of Reagent ───
  const reagentAvailSection = document.createElement('div');
  reagentAvailSection.className = 'form-section reagent-availability-section';

  const reagentAvailGroup = createFormGroup(
    translate('Availability of Reagent'),
    'reagentAvailability',
    [
      { value: 'low',  label: translate('Commercially available at low cost'), score: '10' },
      { value: 'high', label: translate('High cost or require synthesis'), score: '5' }
    ],
    state.reagentAvailability || 'low',
    (value) => onChange('reagentAvailability', value)
  );
  reagentAvailGroup.classList.add('practicality-option');
  reagentAvailSection.appendChild(reagentAvailGroup);
  form.appendChild(reagentAvailSection);

  // ─── 7. Availability of Instrument & Cost of Analysis ───
  const instrCostSection = document.createElement('div');
  instrCostSection.className = 'form-section instrument-cost-section';

  const instrCostGroup = createFormGroup(
    translate('Instrument availability & cost per sample'),
    'instrCost',
    [
      { value: 'all_low',    label: translate('All instruments available + low cost (<$100)'),     score: '10' },
      { value: 'one_med',    label: translate('One special needed + medium/high cost ($100–300)'), score: '5'  },
      { value: 'many_high',  label: translate('More instruments needed + high cost (>$300)'),       score: '0'  }
    ],
    state.instrCost || 'all_low',
    (value) => onChange('instrCost', value)
  );
  instrCostGroup.classList.add('practicality-option');
  instrCostSection.appendChild(instrCostGroup);
  form.appendChild(instrCostSection);

  
  // Efficiency Section
  const efficiencySection = document.createElement('div');
  efficiencySection.className = 'form-section efficiency-section';
  
  // 9. Time of Analysis (Throughput)
  const throughputGroup = createFormGroup(
    translate('Time of Analysis (Throughput)'),
    'throughput',
    [
      { value: 'high', label: translate('High throughput (≥25 samples/hr)'), score: '10' },
      { value: 'medium', label: translate('Medium throughput (13-24 samples/hr)'), score: '5' },
      { value: 'low', label: translate('Low throughput (≤12 samples/hr)'), score: '0' }
    ],
    state.throughput || 'high',
    (value) => onChange('throughput', value)
  );
  throughputGroup.classList.add('practicality-option');
  efficiencySection.appendChild(throughputGroup);
  
  // 10. Sample Reusability
  const reusabilityGroup = createFormGroup(
    translate('Sample Reusability'),
    'reusability',
    [
      { value: 'yes', label: translate('Yes, sample can be reused'), score: '10' },
      { value: 'no', label: translate('No, sample cannot be reused'), score: '0' }
    ],
    state.reusability || 'yes',
    (value) => onChange('reusability', value)
  );
  reusabilityGroup.classList.add('practicality-option');
  efficiencySection.appendChild(reusabilityGroup);
  form.appendChild(efficiencySection);
  
  // We've removed the "Criteria and Scoring Scheme" section as requested
  
  // Add formula note
  const formulaNote = document.createElement('div');
  formulaNote.className = 'formula-note';
  formulaNote.style.marginTop = '20px';
  formulaNote.style.padding = '15px';
  formulaNote.style.backgroundColor = '#f0f8ff';
  formulaNote.style.borderLeft = '4px solid var(--practicality-color)';
  formulaNote.style.borderRadius = '8px';
  formulaNote.style.boxShadow = '0 2px 5px rgba(0,0,0,0.05)';
  formulaNote.innerHTML = `
  <p>${translate('Practicality Index (PI) = ∑ (Weighted scores from 10 core criteria)')}</p>
  <p>${translate('EIPI Total Score = (EI score × 0.5) + (PI × 0.5)')}</p>
  <p>${translate('Interpretation of PI Scores:')}</p>
  <ul>
    <li>${translate('75–100: Excellent Practicality – Highly applicable and efficient')}</li>
    <li>${translate('50–74: Acceptable Practicality – Viable with moderate optimization')}</li>
    <li>${translate('<50: Impractical – Limited real-world feasibility, needs improvement')}</li>
  </ul>
`;
;
  form.appendChild(formulaNote);
    // ─── COMPUTE PRACTICALITY SCORE ───
  const currentPI = calculatePracticalityScore(state);

  // ─── PINNED HORIZONTAL PROGRESS BAR ───
  const piProgressBar = createHorizontalProgressBar(
    currentPI,
    100,
    getPracticalityColor(currentPI),
    translate('Practicality Score')
  );
  form.style.position = 'relative';
  piProgressBar.style.position = 'absolute';
  piProgressBar.style.top = '20px';
  piProgressBar.style.right = '20px';
  piProgressBar.style.width = '180px';
  form.appendChild(piProgressBar);

  // ─── BUILD FIVE‐SLICE RADAR DATA ───
  const radarData = [];
  if (scores.samplePrep !== undefined) {
    radarData.push({
      name: translate('Sample Prep'),
      value: scores.samplePrep,
      color: getEIColor(scores.samplePrep)
    });
  }
  if (scores.instrumentation !== undefined) {
    radarData.push({
      name: translate('Instrumentation'),
      value: scores.instrumentation,
      color: getEIColor(scores.instrumentation)
    });
  }
  if (scores.reagent !== undefined) {
    radarData.push({
      name: translate('Reagent'),
      value: scores.reagent,
      color: getEIColor(scores.reagent)
    });
  }
  if (scores.waste !== undefined) {
    radarData.push({
      name: translate('Waste'),
      value: scores.waste,
      color: getEIColor(scores.waste)
    });
  }
  // Use this page’s own Practicality score:
  radarData.push({
    name: translate('Practicality'),
    value: currentPI,
    color: getPracticalityColor(currentPI)
  });

  // ─── REMOVE OLD CHART & APPEND NEW COXCOMB ───
  const oldChart = document.getElementById('coxcombChart');
  if (oldChart) oldChart.remove();

  const coxcombChart = createCoxcombChart(radarData);
  coxcombChart.id = 'coxcombChart';
  coxcombChart.style.position = 'fixed';
  coxcombChart.style.top = '200px';
  coxcombChart.style.right = '10px';
  coxcombChart.style.width = '25vw';
  coxcombChart.style.height = 'auto';
  coxcombChart.style.zIndex = '999';
  coxcombChart.style.pointerEvents = 'none';
  document.body.appendChild(coxcombChart);

  // Shift page content left so the chart doesn’t overlap:
  document.body.style.marginRight = '25vw';

  return form;
}

function createFormGroup(label, name, options, selectedValue, onChange) {
  const group = document.createElement('div');
  group.className = 'form-group';
  
  const groupLabel = document.createElement('label');
  groupLabel.textContent = label;
  groupLabel.htmlFor = name;
  groupLabel.style.fontSize = '1.2rem';
  groupLabel.style.fontWeight = '600';
  groupLabel.style.marginBottom = '15px';
  groupLabel.style.display = 'block';
  group.appendChild(groupLabel);
  
  options.forEach((option, index) => {
    // Create custom radio container
    const radioContainer = document.createElement('label');
    radioContainer.className = 'custom-radio-container';
    radioContainer.htmlFor = `${name}_${option.value}`;
    
    // Create actual radio input (hidden)
    const radio = document.createElement('input');
    radio.className = 'custom-radio-input';
    radio.type = 'radio';
    radio.id = `${name}_${option.value}`;
    radio.name = name;
    radio.value = option.value;
    radio.checked = selectedValue === option.value;
    radio.addEventListener('change', () => onChange(option.value));
    
    // Create custom radio visual element
    const radioCheckmark = document.createElement('span');
    radioCheckmark.className = 'radio-checkmark';
    
    // Create label text
    const labelText = document.createTextNode(option.label);
    
    // Create score display
    const scoreSpan = document.createElement('span');
    scoreSpan.className = 'option-score';
    scoreSpan.textContent = option.score;
    
    // Append all elements
    radioContainer.appendChild(radio);
    radioContainer.appendChild(radioCheckmark);
    radioContainer.appendChild(labelText);
    radioContainer.appendChild(scoreSpan);
    
    group.appendChild(radioContainer);
  });
  
  return group;
}