import { translate } from './i18n.js';

// Function to generate a PDF report of the EI scale calculation
export async function generatePDF(state) {
  // Create a blob URL for the PDF
  const { jsPDF } = window.jspdf;
  
  // Check if jsPDF is available
  if (!jsPDF) {
    // Load jsPDF from CDN if not available
    await loadJsPDF();
  }
  
  // Load additional dependency for canvas conversion
  await loadScript('https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js');
  
  const doc = new window.jspdf.jsPDF();
  
  // Add title
  doc.setFontSize(20);
  doc.setTextColor(0, 0, 0);
  doc.text(translate('Environmental Impact (EI) Scale Report'), 105, 20, { align: 'center' });
  
  // Add date
  doc.setFontSize(12);
  doc.text(`${translate('Date')}: ${new Date().toLocaleString()}`, 20, 30);
  
  // Add scores
  doc.setFontSize(16);
  doc.text(translate('EI Scale Scores'), 20, 45);
  
  doc.setFontSize(12);
  doc.text(`${translate('Sample Preparation Score')}: ${state.scores.samplePrep.toFixed(1)}`, 20, 55);
  doc.text(`${translate('Instrumentation Score')}: ${state.scores.instrumentation.toFixed(1)}`, 20, 65);
  doc.text(`${translate('Reagent Score')}: ${state.scores.reagent.toFixed(1)}`, 20, 75);
  doc.text(`${translate('Waste Score')}: ${state.scores.waste.toFixed(1)}`, 20, 85);
  
  // Add total score
  doc.setFontSize(16);
  doc.setTextColor(0, 0, 0);
  doc.text(`${translate('Total EI Score')}: ${state.scores.total.toFixed(1)}`, 20, 100);
  
  // Add interpretation
  let interpretationText = '';
  let interpretationColor = [0, 0, 0];
  
  if (state.scores.total === 0) {
    interpretationText = translate('No impact - Ideal green analytical method');
    interpretationColor = [0, 128, 0]; // Dark green
  } else if (state.scores.total <= 25) {
    interpretationText = translate('Minimal impact - Environmentally friendly and sustainable');
    interpretationColor = [46, 204, 113]; // Light green
  } else if (state.scores.total <= 50) {
    interpretationText = translate('Considerable impact - Method requires improvements for sustainability');
    interpretationColor = [243, 156, 18]; // Yellow
  } else {
    interpretationText = translate('Serious impact - Unsustainable method needing urgent intervention');
    interpretationColor = [231, 76, 60]; // Red
  }
  
  doc.setTextColor(interpretationColor[0], interpretationColor[1], interpretationColor[2]);
  doc.text(`${translate('Environmental Impact Interpretation')}: ${interpretationText}`, 20, 110);
  
  // Reset text color
  doc.setTextColor(0, 0, 0);
  
  // Add details for each component
  doc.addPage();
  
  // Sample Preparation Details
  doc.setFontSize(16);
  doc.text(translate('Sample Preparation Details'), 20, 20);
  doc.setFontSize(12);
  let yPos = 30;
  
  // Pre-synthesis
  doc.text(`${translate('Pre-synthesis')}: ${state.samplePrep.preSynthesis === 'no' ? translate('No') : translate('Yes')}`, 20, yPos);
  yPos += 10;
  
  if (state.samplePrep.preSynthesis === 'yes') {
    doc.text(`${translate('Yield')}: ${getYieldText(state.samplePrep.yield)}`, 30, yPos);
    yPos += 10;
    doc.text(`${translate('Temperature')}: ${getTemperatureText(state.samplePrep.temperature)}`, 30, yPos);
    yPos += 10;
    
    if (state.samplePrep.purification) {
      doc.text(`${translate('Purification needed')}: ${translate('Yes')}`, 30, yPos);
      yPos += 10;
    }
    
    if (state.samplePrep.energyConsumption) {
      doc.text(`${translate('High energy consumption')}: ${translate('Yes')}`, 30, yPos);
      yPos += 10;
    }
    
    if (state.samplePrep.nonGreenSolvent) {
      doc.text(`${translate('Use of non-green solvent')}: ${translate('Yes')}`, 30, yPos);
      yPos += 10;
    }
    
    if (state.samplePrep.occupationalHazard) {
      doc.text(`${translate('Occupational hazard present')}: ${translate('Yes')}`, 30, yPos);
      yPos += 10;
    }
  }
  
  // Instrument requirements
  doc.text(`${translate('Instrument requirements')}: ${getInstrumentRequirementsText(state.samplePrep.instrumentRequirements)}`, 20, yPos);
  yPos += 10;
  
  // Type of sample
  doc.text(`${translate('Type of sample')}: ${state.samplePrep.sampleType === 'simple' ? translate('Simple') : translate('Extensive')}`, 20, yPos);
  yPos += 10;
  
  if (state.samplePrep.derivatization) {
    doc.text(`${translate('Involves derivatization or digestion')}: ${translate('Yes')}`, 30, yPos);
    yPos += 10;
  }
  
  doc.text(`${translate('Sample throughput')}: ${getSampleThroughputText(state.samplePrep.sampleThroughput)}`, 30, yPos);
  yPos += 10;
  
  if (state.samplePrep.automatedPreparation) {
    doc.text(`${translate('Automated sample preparation')}: ${translate('Yes')}`, 30, yPos);
    yPos += 10;
  }
  
  if (state.samplePrep.inSituPreparation) {
    doc.text(`${translate('In situ sample preparation')}: ${translate('Yes')}`, 30, yPos);
    yPos += 10;
  }
  
  if (state.samplePrep.offLine) {
    doc.text(`${translate('Off line')}: ${translate('Yes')}`, 30, yPos);
    yPos += 10;
  }
  
  // Extraction procedure
  doc.text(`${translate('Extraction procedure')}: ${state.samplePrep.extractionNeeded === 'no' ? translate('No extraction needed') : translate('Extraction needed')}`, 20, yPos);
  yPos += 10;
  
  if (state.samplePrep.extractionNeeded === 'yes') {
    doc.text(`${translate('Solvent Type')}: ${getExtractionSolventTypeText(state.samplePrep.solventType)}`, 30, yPos);
    yPos += 10;
    
    doc.text(`${translate('Solvent Volume')}: ${getSolventVolumeText(state.samplePrep.solventVolume)}`, 30, yPos);
    yPos += 10;
    
    if (state.samplePrep.renewableAdsorbent) {
      doc.text(`${translate('Use of renewable/reusable absorbents')}: ${translate('Yes')}`, 30, yPos);
      yPos += 10;
    }
  }
  
  // Instrumentation Details
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  } else {
    yPos += 10;
  }
  
  doc.setFontSize(16);
  doc.text(translate('Instrumentation Details'), 20, yPos);
  doc.setFontSize(12);
  yPos += 10;
  
  doc.text(`${translate('Energy Consumption')}: ${getEnergyText(state.instrumentation.energy)}`, 20, yPos);
  yPos += 10;
  
  if (state.instrumentation.vaporEmission) {
    doc.text(`${translate('Emission of Vapors')}: ${translate('Yes')}`, 20, yPos);
    yPos += 10;
  }
  
  if (state.instrumentation.nonAutomated) {
    doc.text(`${translate('Manual or non-automated')}: ${translate('Yes')}`, 20, yPos);
    yPos += 10;
  }
  
  if (state.instrumentation.notMultianalyte) {
    doc.text(`${translate('Not multianalyte or multiparameter')}: ${translate('Yes')}`, 20, yPos);
    yPos += 10;
  }
  
  doc.text(`${translate('Maintenance and Instrument Lifetime')}: ${state.instrumentation.maintenanceLifetime}`, 20, yPos);
  yPos += 10;
  
  // Reagent Details
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  } else {
    yPos += 10;
  }
  
  doc.setFontSize(16);
  doc.text(translate('Reagent Details'), 20, yPos);
  doc.setFontSize(12);
  yPos += 10;
  
  if (state.reagents.length === 0) {
    doc.text(translate('No reagents added'), 20, yPos);
    yPos += 10;
  } else {
    state.reagents.forEach((reagent, index) => {
      doc.text(`${translate('Reagent')} ${index + 1}:`, 20, yPos);
      yPos += 10;
      
      doc.text(`${translate('Solvent')}: ${getSolventTypeText(reagent.solventType)}`, 30, yPos);
      yPos += 10;
      
      doc.text(`${translate('Signal Word')}: ${getSignalWordText(reagent.signalWord)}`, 30, yPos);
      yPos += 10;
      
      doc.text(`${translate('GHS Classification')}: ${getGHSClassText(reagent.ghsClass)}`, 30, yPos);
      yPos += 10;
      
      doc.text(`${translate('Volume')}: ${getReagentVolumeText(reagent.volume)}`, 30, yPos);
      yPos += 10;
      
      // Add more space between reagents
      yPos += 5;
      
      // Check if we need a new page
      if (yPos > 270 && index < state.reagents.length - 1) {
        doc.addPage();
        yPos = 20;
      }
    });
  }
  
  // Waste Details
  if (yPos > 250) {
    doc.addPage();
    yPos = 20;
  } else {
    yPos += 10;
  }
  
  doc.setFontSize(16);
  doc.text(translate('Waste Details'), 20, yPos);
  doc.setFontSize(12);
  yPos += 10;
  
  doc.text(`${translate('Amount of Waste per Sample')}: ${getWasteVolumeText(state.waste.volume)}`, 20, yPos);
  yPos += 10;
  
  doc.text(`${translate('Biodegradable')}: ${state.waste.biodegradable ? translate('Yes') : translate('No')}`, 20, yPos);
  yPos += 10;
  
  doc.text(`${translate('Treatment')}: ${getWasteTreatmentText(state.waste.treatment)}`, 20, yPos);
  
  // Add visualization charts to a new page
  doc.addPage();
  
  // Add title for visualization section
  doc.setFontSize(18);
  doc.text(translate('Visualization Charts'), 105, 20, { align: 'center' });
  
  // Set starting position for charts
  let chartYPosition = 30;
  
  // Add warning text if charts may not be visible
  doc.setFontSize(10);
  doc.setTextColor(150, 150, 150);
  doc.text(translate('Note: If charts are not visible, please ensure they were rendered before export.'), 105, chartYPosition, { align: 'center' });
  doc.setTextColor(0, 0, 0);
  chartYPosition += 15;
  
  // Capture and add bar chart
  try {
    const barCanvas = document.getElementById('barChart');
    if (barCanvas) {
      chartYPosition = await addChartToPDF(doc, 'barChart', translate('Component Scores Comparison'), chartYPosition);
    }
    
    // Capture and add radar chart if available
    const radarCanvas = document.getElementById('radarChart');
    if (radarCanvas) {
      // Check if we need a new page
      if (chartYPosition > 200) {
        doc.addPage();
        chartYPosition = 20;
      }
      
      chartYPosition = await addChartToPDF(doc, 'radarChart', translate('Environmental Impact Radar'), chartYPosition);
    }
    
    // Capture and add polar area chart if available
    const polarCanvas = document.getElementById('polarChart');
    if (polarCanvas) {
      // Check if we need a new page
      if (chartYPosition > 200) {
        doc.addPage();
        chartYPosition = 20;
      }
      
      chartYPosition = await addChartToPDF(doc, 'polarChart', translate('EI Component Distribution'), chartYPosition);
    }
  } catch (chartError) {
    console.error('Error adding charts to PDF:', chartError);
    
    // Add error message if charts couldn't be added
    doc.setFontSize(12);
    doc.setTextColor(255, 0, 0);
    doc.text(translate('Error: Could not include charts in the PDF.'), 20, chartYPosition);
    doc.setTextColor(0, 0, 0);
  }
  
  // Trigger download
  try {
    const pdfBlob = doc.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    
    // Create a link and click it to trigger download
    const link = document.createElement('a');
    link.href = pdfUrl;
    link.download = `EI_Scale_Report_${new Date().toISOString().split('T')[0]}.pdf`;
    link.click();
    
    // Clean up
    URL.revokeObjectURL(pdfUrl);
  } catch (error) {
    console.error('Error generating PDF:', error);
    
    // Try using the save method directly if the above fails
    try {
      doc.save(`EI_Scale_Report_${new Date().toISOString().split('T')[0]}.pdf`);
    } catch (saveError) {
      console.error('Error saving PDF:', saveError);
      alert(translate('Failed to generate PDF. Please try again.'));
    }
  }
}

// Helper functions to get text values for various parameters
function getYieldText(yieldValue) {
  switch (yieldValue) {
    case 'high': return translate('High yield >90%');
    case 'moderate': return translate('Moderate yield 50-90%');
    case 'low': return translate('Low yield <50%');
    default: return yieldValue;
  }
}

function getTemperatureText(temperature) {
  switch (temperature) {
    case 'high': return translate('High temp. for more than 1 hr or cooling less than 0°C');
    case 'room': return translate('Room temperature more than 1 hr or heating less than 1 hr');
    case 'none': return translate('No temperature control required');
    default: return temperature;
  }
}

function getInstrumentRequirementsText(requirements) {
  switch (requirements) {
    case 'none': return translate('No sample preparation required');
    case 'minimal': return translate('Minimal sample preparation (Dilution)');
    case 'moderate': return translate('Moderate sample preparation (Filtration, sonication)');
    default: return requirements;
  }
}

function getSampleThroughputText(throughput) {
  switch (throughput) {
    case 'high': return translate('High (≥60 samples/day)');
    case 'moderate': return translate('Moderate (30–59 samples/day)');
    case 'low': return translate('Low (<30 samples/day)');
    default: return throughput;
  }
}

function getExtractionSolventTypeText(type) {
  switch (type) {
    case 'complete': return translate('Complete green solvents');
    case 'partial': return translate('Partial green solvents');
    case 'nonGreen': return translate('Non-greener (conventional organic) solvents');
    default: return type;
  }
}

function getSolventVolumeText(volume) {
  switch (volume) {
    case 'less1': return translate('Less than 1 mL');
    case 'between1And10': return translate('1 to 10 mL');
    case 'between10And100': return translate('10 to 100 mL');
    case 'more100': return translate('More than 100 mL');
    default: return volume;
  }
}

function getEnergyText(energy) {
  switch (energy) {
    case 'non': return translate('Non-instrumental methods (0 kWh)');
    case 'low': return translate('≤0.1 kWh per sample');
    case 'moderate': return translate('≤1.5 kWh per sample');
    case 'high': return translate('>1.5 kWh per sample');
    default: return energy;
  }
}

function getSolventTypeText(type) {
  switch (type) {
    case 'water': return translate('Water');
    case 'organic': return translate('Organic Solvent');
    case 'acid': return translate('Acid');
    case 'base': return translate('Base');
    case 'buffer': return translate('Buffer');
    case 'other': return translate('Other');
    default: return type;
  }
}

function getSignalWordText(signalWord) {
  switch (signalWord) {
    case 'warning': return translate('Warning');
    case 'danger': return translate('Danger');
    case 'notAvailable': return translate('Not available');
    default: return signalWord;
  }
}

function getGHSClassText(ghsClass) {
  switch (ghsClass) {
    case 'zero': return translate('Zero pictograms');
    case 'one': return translate('One pictogram');
    case 'two': return translate('Two pictograms');
    case 'three': return translate('Three or more pictograms');
    default: return ghsClass;
  }
}

function getReagentVolumeText(volume) {
  switch (volume) {
    case 'less1': return translate('< 1 ml');
    case 'less10': return translate('< 10 ml (g)');
    case 'between10And100': return translate('10-100 ml (g)');
    case 'more100': return translate('> 100 ml (g)');
    default: return volume;
  }
}

function getWasteVolumeText(volume) {
  switch (volume) {
    case 'less1': return translate('< 1 mL');
    case 'between1And10': return translate('1-10 mL');
    case 'between10And100': return translate('11-100 mL');
    case 'more100': return translate('> 100 mL');
    default: return volume;
  }
}

function getWasteTreatmentText(treatment) {
  switch (treatment) {
    case 'none': return translate('No treatment applied');
    case 'noModification': return translate('No modification required');
    case 'less10': return translate('Treatment with reuse < 10 mL');
    case 'more10': return translate('Treatment with reuse > 10 mL');
    default: return treatment;
  }
}

// Generic function to load external scripts
async function loadScript(url) {
  return new Promise((resolve, reject) => {
    // Check if script already loaded
    const existingScript = document.querySelector(`script[src="${url}"]`);
    if (existingScript) {
      resolve();
      return;
    }
    
    const script = document.createElement('script');
    script.src = url;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error(`Failed to load script: ${url}`));
    document.head.appendChild(script);
  });
}

// Load jsPDF from CDN if not available
async function loadJsPDF() {
  return new Promise((resolve, reject) => {
    if (window.jspdf) {
      resolve();
      return;
    }
    
    // For the web version, jsPDF should already be loaded in the index.html
    if (typeof jspdf !== 'undefined') {
      window.jspdf = jspdf;
      resolve();
      return;
    }
    
    // Otherwise, try to load it
    loadScript('https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js')
      .then(() => resolve())
      .catch(error => reject(error));
  });
}

// Function to capture chart canvas and add to PDF
async function addChartToPDF(doc, canvasId, title, yPosition, width = 170, height = 100) {
  try {
    const canvas = document.getElementById(canvasId);
    
    if (!canvas) {
      console.warn(`Canvas with ID ${canvasId} not found`);
      return yPosition;
    }
    
    // Add title
    doc.setFontSize(14);
    doc.text(title, 20, yPosition);
    yPosition += 10;
    
    const imgData = canvas.toDataURL('image/png');
    
    // Calculate center position for the chart
    const pageWidth = doc.internal.pageSize.getWidth();
    const xPosition = (pageWidth - width) / 2;
    
    doc.addImage(imgData, 'PNG', xPosition, yPosition, width, height);
    
    return yPosition + height + 20; // Return the new Y position after adding the chart
  } catch (error) {
    console.error('Error capturing chart:', error);
    return yPosition;
  }
}
