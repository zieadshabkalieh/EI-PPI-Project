// This file contains all the calculation logic for the EI scale
export function calculateTotalEIScore(samplePrep, instrumentation, reagents, waste, practicality) {
  // Calculate all component scores
  const samplePrepScore = calculateSamplePrepScore(samplePrep);
  const instrumentationScore = calculateInstrumentationScore(instrumentation);
  const reagentScore = calculateReagentScore(reagents);
  const wasteScore = calculateWasteScore(waste);
  
  // Calculate EI Index score (SIRW)
  // EI index = (Sample preparation score + Reagent score + Instrumentation score + Waste score) / 4
  const eiIndexScore = (samplePrepScore + instrumentationScore + reagentScore + wasteScore) / 4;
  
  // Calculate Practicality Index score if available
  let practicalityScore = 0;
  if (practicality) {
    practicalityScore = calculatePracticalityScore(practicality);
  }
  
  // Calculate total EI Scale: 70% EI Index + 30% Practicality Index
  const totalScore = (eiIndexScore * 0.7) + (practicalityScore * 0.3);
  
  // Format scores with one decimal place
  return {
    samplePrep: parseFloat(samplePrepScore.toFixed(1)),
    instrumentation: parseFloat(instrumentationScore.toFixed(1)),
    reagent: parseFloat(reagentScore.toFixed(1)),
    waste: parseFloat(wasteScore.toFixed(1)),
    eiIndex: parseFloat(eiIndexScore.toFixed(1)),
    practicality: parseFloat(practicalityScore.toFixed(1)),
    total: parseFloat(totalScore.toFixed(1))
  };
}

// Function to calculate Sample Preparation Score
function calculateSamplePrepScore(samplePrep) {
  // Main components scores
  let preSynthesisScore = 0;
  let samplingRequiredScore = 0;
  let sampleTypeScore = 0;
  let sampleThroughputScore = 0;
  let extractionProcedureScore = 0;
  let otherConditionsScore = 0;
  
  // 1. Pre-synthesis score (1.1 in document)
  if (samplePrep.preSynthesis === 'no') {
    preSynthesisScore = 100;
  } else {
    preSynthesisScore = 75;
    
    // Modifiers for pre-synthesis if required
    // Yield (1.1.3)
    if (samplePrep.yield === 'high') {
      preSynthesisScore += 5;
    } else if (samplePrep.yield === 'moderate') {
      preSynthesisScore += 0;
    } else if (samplePrep.yield === 'low') {
      preSynthesisScore -= 5;
    }
    
    // Temperature (1.1.4)
    if (samplePrep.temperature === 'high') {
      preSynthesisScore -= 10;
    } else if (samplePrep.temperature === 'room') {
      preSynthesisScore -= 5;
    }
    
    // Additional modifiers
    if (samplePrep.purification) preSynthesisScore -= 5; // 1.1.5.1
    if (samplePrep.energyConsumption) preSynthesisScore -= 5; // 1.1.6.1
    if (!samplePrep.energyConsumption) preSynthesisScore += 5; // 1.1.6.2
    if (samplePrep.nonGreenSolvent) preSynthesisScore -= 5; // 1.1.7.1
    if (!samplePrep.nonGreenSolvent) preSynthesisScore += 5; // 1.1.7.2
    if (samplePrep.occupationalHazard) preSynthesisScore -= 5; // 1.1.8.1
    if (!samplePrep.occupationalHazard) preSynthesisScore += 5; // 1.1.8.2
  }
  
  // 2. Sampling required (1.2 in document)
  if (samplePrep.instrumentRequirements === 'none') {
    samplingRequiredScore = 100; // 1.2.1
  } else if (samplePrep.instrumentRequirements === 'minimal') {
    samplingRequiredScore = 90; // 1.2.2
  } else if (samplePrep.instrumentRequirements === 'moderate') {
    samplingRequiredScore = 80; // 1.2.3
  } else if (samplePrep.instrumentRequirements === 'high') {
    samplingRequiredScore = 70; // 1.2.4
  }
  
  // 3. Type of sample and sample efficiency (1.3 in document)
  if (samplePrep.sampleType === 'simple') {
    sampleTypeScore = 100; // 1.3.1
  } else if (samplePrep.sampleType === 'extensive') {
    sampleTypeScore = 50; // 1.3.2
  }
  
  // 4. Sample throughput (1.4 in document)
  if (samplePrep.sampleThroughput === 'high') {
    sampleThroughputScore = 100; // 1.4.1
  } else if (samplePrep.sampleThroughput === 'moderate') {
    sampleThroughputScore = 50; // 1.4.2
  } else if (samplePrep.sampleThroughput === 'low') {
    sampleThroughputScore = 25; // 1.4.3
  }
  
  // 5. Extraction procedure (1.5 in document)
  if (samplePrep.extractionNeeded === 'no') {
    extractionProcedureScore = 100; // 1.5.1
  } else {
    extractionProcedureScore = 60; // 1.5.2
    
    // Solvent type (1.5.2.1)
    if (samplePrep.solventType === 'complete') {
      extractionProcedureScore += 10; // 1.5.2.1.1
    } else if (samplePrep.solventType === 'partial') {
      extractionProcedureScore += 5; // 1.5.2.1.2
    } else if (samplePrep.solventType === 'nonGreen') {
      extractionProcedureScore -= 10; // 1.5.2.1.3
    }
    
    // Solvent volume (1.5.2.2)
    if (samplePrep.solventVolume === 'less1') {
      extractionProcedureScore += 20; // 1.5.2.2.1
    } else if (samplePrep.solventVolume === '1to10') {
      extractionProcedureScore += 10; // 1.5.2.2.2
    } else if (samplePrep.solventVolume === '10to100') {
      extractionProcedureScore += 5; // 1.5.2.2.3
    } else if (samplePrep.solventVolume === 'more100') {
      extractionProcedureScore -= 20; // 1.5.2.2.4
    }
    
    // Solid phase used (1.5.2.3)
    if (samplePrep.solidPhase === 'oneTime') {
      extractionProcedureScore -= 10; // 1.5.2.3.1
    } else if (samplePrep.solidPhase === 'reusable') {
      extractionProcedureScore += 10; // 1.5.2.3.2
    } // 'na' adds 0 (1.5.2.3.3)
  }
  
  // 6. Other conditions (1.6 in document)
  otherConditionsScore = 0;
  
  // Sampling Requires Derivatization (1.6.1)
  if (samplePrep.derivatization === true) {
    otherConditionsScore -= 10; // 1.6.1.1
  } // 'no' adds 0 (1.6.1.2)
  
  // Automated sample preparation (1.6.2)
  if (samplePrep.automatedPreparation === true) {
    otherConditionsScore += 10; // 1.6.2.1
  } // 'no' adds 0 (1.6.2.2)
  
  // Type of Sample Preparation (1.6.3)
  if (samplePrep.inSituPreparation === true) {
    otherConditionsScore += 10; // 1.6.3.1
  }
  if (samplePrep.offLine === true) {
    otherConditionsScore -= 10; // 1.6.3.2
  }
  
  // Ensure no negative scores
  preSynthesisScore = Math.max(0, preSynthesisScore);
  samplingRequiredScore = Math.max(0, samplingRequiredScore);
  sampleTypeScore = Math.max(0, sampleTypeScore);
  sampleThroughputScore = Math.max(0, sampleThroughputScore);
  extractionProcedureScore = Math.max(0, extractionProcedureScore);
  
  // Calculate final score according to document formula
  // The overall formula was sum of 1.1, 1.2, 1.3, 1.4, 1.5, add sum obtained with 1.6
  // but the overall score should be not more than 100
  const mainComponentsAvg = (preSynthesisScore + samplingRequiredScore + sampleTypeScore + 
                             sampleThroughputScore + extractionProcedureScore) / 5;
  
  let finalScore = mainComponentsAvg + otherConditionsScore;
  
  // Cap the score at 100
  return Math.min(100, Math.max(0, finalScore));
}

// Function to calculate Instrumentation Score
function calculateInstrumentationScore(instrumentation) {
  // Base score from energy consumption
  let score = 0;
  
  // 1. Energy Consumption
  if (instrumentation.energy === 'non') {
    score = 100; // Non-instrumental methods (0 kWh)
  } else if (instrumentation.energy === 'low') {
    score = 95; // ≤0.1 kWh per sample
  } else if (instrumentation.energy === 'moderate') {
    score = 85; // ≤1.5 kWh per sample
  } else if (instrumentation.energy === 'high') {
    score = 75; // >1.5 kWh per sample
  }
  
  // 2. Apply other modifiers
  
  // Emission of Vapors
  if (instrumentation.vaporEmission) {
    score -= 20;
  }
  
  // Manual or non-automated
  if (instrumentation.nonAutomated) {
    score -= 5;
  }
  
  // Not multianalyte or multiparameter
  if (instrumentation.notMultianalyte) {
    score -= 5;
  }
  
  // Miniaturized instrument
  if (instrumentation.miniaturized) {
    score += 10;
  }
  
  // Ensure score is not negative and not greater than 100
  score = Math.min(100, Math.max(0, score));
  
  return score;
}

// Function to calculate Reagent Score
function calculateReagentScore(reagents) {
  if (reagents.length === 0) {
    return 100; // If no reagents, assume perfect score (water only)
  }
  
  let totalScore = 0;
  
  // Calculate score for each reagent
  reagents.forEach(reagent => {
    let reagentScore = 0;
    
    // If it's water with zero pictograms
    if (reagent.solventType === 'water' && reagent.ghsClass === 'zero') {
      reagentScore = 100;
    }
    // Base score on GHS classification and signal word combination
    else if (reagent.ghsClass === 'zero') {
      reagentScore = 100; // Zero pictograms
    } 
    else if (reagent.ghsClass === 'one' && reagent.signalWord === 'warning') {
      // One pictogram + Warning
      switch (reagent.volume) {
        case 'less1': reagentScore = 98; break;
        case 'less10': reagentScore = 96; break;
        case 'between10And100': reagentScore = 94; break;
        case 'more100': reagentScore = 92; break;
      }
    } 
    else if ((reagent.ghsClass === 'one' && reagent.signalWord === 'danger') || 
            (reagent.ghsClass === 'two' && reagent.signalWord === 'warning')) {
      // One pictogram + Danger OR Two pictograms + Warning
      switch (reagent.volume) {
        case 'less1': reagentScore = 90; break;
        case 'less10': reagentScore = 85; break;
        case 'between10And100': reagentScore = 80; break;
        case 'more100': reagentScore = 75; break;
      }
    } 
    else if (reagent.ghsClass === 'two' && reagent.signalWord === 'danger') {
      // Two pictograms + Danger
      switch (reagent.volume) {
        case 'less1': reagentScore = 70; break;
        case 'less10': reagentScore = 65; break;
        case 'between10And100': reagentScore = 60; break;
        case 'more100': reagentScore = 55; break;
      }
    } 
    else if (reagent.ghsClass === 'three') {
      // Three or more pictograms + Danger
      switch (reagent.volume) {
        case 'less1': reagentScore = 50; break;
        case 'less10': reagentScore = 45; break;
        case 'between10And100': reagentScore = 40; break;
        case 'more100': reagentScore = 35; break;
      }
    }
    
    totalScore += reagentScore;
  });
  
  // Average the scores
  return totalScore / reagents.length;
}

// Function to calculate Waste Score
function calculateWasteScore(waste) {
  let score = 0;
  
  // Base score based on volume and biodegradability
  if (waste.volume === 'less1') {
    score = 100;
  } else if (waste.volume === 'between1And10') {
    score = waste.biodegradable ? 90 : 80;
  } else if (waste.volume === 'between10And100') {
    score = waste.biodegradable ? 70 : 50;
  } else if (waste.volume === 'more100') {
    score = waste.biodegradable ? 35 : 25;
  }
  
  // Apply biodegradability modifier
  if (waste.biodegradable) {
    score += 15; // +15 for biodegradable waste
  } else {
    score -= 15; // -15 for non-biodegradable waste
  }
  
  // Treatment modifiers
  if (waste.treatment === 'none') {
    score -= 5;
  } else if (waste.treatment === 'less10') {
    score += 10;
  } else if (waste.treatment === 'more10') {
    score += 20;
  }
  
  // Ensure score is between 0 and 100
  score = Math.min(100, Math.max(0, score));
  
  return score;
}

// Function to calculate Practicality Index Score
function calculatePracticalityScore(practicality) {
  let score = 0;
  
  // 1. Nature of Method
  if (practicality.natureOfMethod === 'quantitative') {
    score += 10;
  } else if (practicality.natureOfMethod === 'qualitative') {
    score += 5;
  }
  
  // 2. Design of Experiment
  if (practicality.designOfExperiment === 'factorial') {
    score += 10;
  } else if (practicality.designOfExperiment === 'ofat') {
    score += 5;
  } // 'none' adds 0
  
  // 3. Validation
  if (practicality.validation === 'full') {
    score += 25;
  } else if (practicality.validation === 'partial') {
    score += 10;
  } // 'none' adds 0
  
  // 4. Sensitivity
  if (practicality.sensitivity === 'picogram') {
    score += 10;
  } else if (practicality.sensitivity === 'nanogram') {
    score += 8;
  } else if (practicality.sensitivity === 'microgram') {
    score += 5;
  } else if (practicality.sensitivity === 'more') {
    score += 2;
  }
  
  // 5. Cost of Reagents
  if (practicality.reagentCost === 'low') {
    score += 8;
  } else if (practicality.reagentCost === 'moderate') {
    score += 5;
  } else if (practicality.reagentCost === 'high') {
    score += 2;
  }
  
  // 6. Cost of Instrument
  if (practicality.instrumentCost === 'low') {
    score += 8;
  } else if (practicality.instrumentCost === 'high') {
    score += 4;
  }
  
  // 7. Maintenance frequency and instrument lifetime
  if (practicality.maintenance === 'long') {
    score += 10;
  } else if (practicality.maintenance === 'frequent') {
    score += 5;
  }
  
  // 8. Time of Analysis (Throughput)
  if (practicality.throughput === 'high') {
    score += 9;
  } else if (practicality.throughput === 'low') {
    score += 4;
  }
  
  // 9. Sample Reusability
  if (practicality.reusability === 'yes') {
    score += 10;
  } // 'no' adds 0
  
  // Ensure score is between 0 and 100
  score = Math.min(100, Math.max(0, score));
  
  return score;
}
