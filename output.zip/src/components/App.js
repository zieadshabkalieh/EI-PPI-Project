import { Header } from './Header.js';
import { Footer } from './Footer.js';
import { SamplePreparationForm } from './forms/SamplePreparationForm.js';
import { InstrumentationForm } from './forms/InstrumentationForm.js';
import { ReagentForm } from './forms/ReagentForm.js';
import { WasteForm } from './forms/WasteForm.js';
import { PracticalityForm } from './forms/PracticalityForm.js';
import { Results } from './Results.js';
import { Visualization } from './Visualization.js';
import { SavedCalculations } from './SavedCalculations.js';
import { calculateTotalEIScore } from '../utils/calculations.js';
import { saveToDB, getCalculations, getCalculationById, deleteCalculation } from '../utils/database.js';
import { generatePDF } from '../utils/pdf.js';
import { generateExcel } from '../utils/excel.js';
import { translate, setLanguage, getCurrentLanguage } from '../utils/i18n.js';
import { createTabWatermark } from '../utils/tab-watermarks.js';
import { 
  showLoader, 
  animateTabTransition, 
  createPageTransition, 
  createReactionAnimation,
  showLoadingWithFacts
} from '../utils/animations.js';
import { showTabLoader } from '../utils/analytical-animations.js';

export function renderApp(container) {
  let currentTab = 'samplePrep';
  let calculationId = null;
  
  // Initial state for all forms
  const state = {
    samplePrep: {
      // 1.1 Pre-synthesis
      preSynthesis: 'no',
      yield: 'high',
      temperature: 'room',
      purification: false,
      energyConsumption: false,
      nonGreenSolvent: false,
      occupationalHazard: false,
      // 1.2 Sampling required
      instrumentRequirements: 'none',
      // 1.3 Type of sample and sample efficiency
      sampleType: 'simple',
      // 1.4 Sample throughput
      sampleThroughput: 'high',
      // 1.5 Extraction procedure
      extractionNeeded: 'no',
      solventType: 'complete',
      solventVolume: 'less1',
      solidPhase: 'na',
      // 1.6 Other conditions
      derivatization: false,
      automatedPreparation: false,
      inSituPreparation: true,
      offLine: false
    },
    instrumentation: {
      energy: 'non',
      vaporEmission: false,
      nonAutomated: false,
      notMultianalyte: false,
      miniaturized: false
    },
    reagents: [], // Initial empty reagents array - will be filled with {solventType, signalWord, ghsClass, volume} objects
    waste: {
      volume: 'less1',
      biodegradable: true,
      treatment: 'less10'  // Default changed from 'none' to 'less10' since we removed 'noModification'
    },
    practicality: {
      natureOfMethod: 'quantitative',
      designOfExperiment: 'factorial',
      validation: 'full',
      sensitivity: 'picogram',
      reagentCost: 'low',
      instrumentCost: 'low',
      maintenance: 'long',
      throughput: 'high',
      reusability: 'yes'
    },
    scores: {
      samplePrep: 0,
      instrumentation: 0,
      reagent: 0,
      waste: 0,
      eiIndex: 0,
      practicality: 0,
      total: 0
    },
    colorClass: 'result-good'
  };
  
  // Render the application
  function render() {
    container.innerHTML = '';
    
    // Create the app structure
    const appContainer = document.createElement('div');
    appContainer.className = 'container';
    
    // Render header
    appContainer.appendChild(Header());
    
    // Create the main content area
    const mainContent = document.createElement('main');
    mainContent.className = 'main-content';
    
    // Create the main tab navigation (with sections)
    const tabNav = document.createElement('div');
    tabNav.className = 'tabs main-tabs';
    
    // Define the main sections
    const mainSections = [
      { 
        id: 'eiIndex', 
        label: translate('EI Index'),
        subTabs: [
          { id: 'samplePrep', label: translate('Sample Preparation') },
          { id: 'instrumentation', label: translate('Instrumentation') },
          { id: 'reagent', label: translate('Reagents') },
          { id: 'waste', label: translate('Waste') }
        ]
      },
      { 
        id: 'practicality', 
        label: translate('Practicality Index'),
        subTabs: [
          { id: 'practicality', label: translate('Practicality Criteria') }
        ]
      },
      { 
        id: 'results', 
        label: translate('Results'),
        subTabs: [
          { id: 'results', label: translate('Results') },
          { id: 'saved', label: translate('Saved Calculations') }
        ]
      }
    ];
    
    // Check if we're in a main section or one of its sub-tabs
    const getCurrentMainSection = (currentTab) => {
      for (const section of mainSections) {
        if (section.id === currentTab) return section.id;
        for (const subTab of section.subTabs) {
          if (subTab.id === currentTab) return section.id;
        }
      }
      return 'eiIndex'; // Default
    };
    
    // Get current active main section
    const currentMainSection = getCurrentMainSection(currentTab);
    
    // Create the main section tabs
    mainSections.forEach(section => {
      const tabElement = document.createElement('div');
      const isActive = currentMainSection === section.id;
      tabElement.className = `tab main-tab tab-${section.id} ${isActive ? 'active' : ''}`;
      tabElement.textContent = section.label;
      tabElement.addEventListener('click', () => {
        // Don't do anything if already on this main section
        if (currentMainSection === section.id) return;
        
        // Show tab-specific transition animation
        const hideLoader = showTabLoader(section.id);
        
        // Switch to the first tab of the section
        setTimeout(() => {
          currentTab = section.subTabs[0].id;
          render();
          hideLoader();
          
          // Ensure watermark is applied after tab switch
          const tabContent = document.querySelector('.tab-content');
          if (tabContent) {
            createTabWatermark(tabContent, currentTab);
          }
        }, 1200);
      });
      tabNav.appendChild(tabElement);
    });
    
    // Append the main tabs to the main content
    mainContent.appendChild(tabNav);
    
    // Only display sub-tabs for the active main section
    const activeSection = mainSections.find(section => section.id === currentMainSection);
    if (activeSection && activeSection.subTabs.length > 0) {
      const subTabNav = document.createElement('div');
      subTabNav.className = 'tabs sub-tabs';
      
      activeSection.subTabs.forEach(tab => {
        const tabElement = document.createElement('div');
        tabElement.className = `tab sub-tab tab-${tab.id} ${currentTab === tab.id ? 'active' : ''}`;
        tabElement.textContent = tab.label;
        tabElement.addEventListener('click', () => {
          // Don't do anything if already on this tab
          if (currentTab === tab.id) return;
          
          // Show tab-specific transition animation
          const hideLoader = showTabLoader(tab.id);
          
          // Switch tabs with slight delay for the animation
          setTimeout(() => {
            currentTab = tab.id;
            render();
            hideLoader();
            
            // Ensure watermark is applied after tab switch
            const tabContent = document.querySelector('.tab-content');
            if (tabContent) {
              createTabWatermark(tabContent, currentTab);
            }
          }, 1200);
        });
        subTabNav.appendChild(tabElement);
      });
      
      // Append sub-tabs after main tabs
      mainContent.appendChild(subTabNav);
    }
    
    // Tab content container
    const tabContent = document.createElement('div');
    tabContent.className = 'tab-content active';
    
    // Add the tab-specific watermark
    createTabWatermark(tabContent, currentTab);
    
    // Render the active tab - force update with timestamp
    const timestamp = Date.now(); // Force re-rendering
    switch (currentTab) {
      case 'samplePrep':
        console.log(`Rendering Sample Preparation Form (${timestamp})`);
        tabContent.appendChild(SamplePreparationForm(state.samplePrep, handleSamplePrepChange));
        break;
      case 'instrumentation':
        console.log(`Rendering Instrumentation Form (${timestamp})`);
        tabContent.appendChild(InstrumentationForm(state.instrumentation, handleInstrumentationChange));
        break;
      case 'reagent':
        console.log(`Rendering Reagent Form (${timestamp})`);
        tabContent.appendChild(ReagentForm(state.reagents, handleReagentChange));
        break;
      case 'waste':
        console.log(`Rendering Waste Form (${timestamp})`);
        tabContent.appendChild(WasteForm(state.waste, handleWasteChange));
        break;
      case 'practicality':
        console.log(`Rendering Practicality Form (${timestamp})`);
        tabContent.appendChild(PracticalityForm(state.practicality, handlePracticalityChange));
        break;
      case 'results':
        calculateScores();
        tabContent.appendChild(Results(state.scores, state.colorClass, state.practicalityColorClass));
        tabContent.appendChild(Visualization(state.scores));
        
        // Add export and save buttons
        const actionButtons = document.createElement('div');
        actionButtons.className = 'action-buttons';
        actionButtons.style.marginTop = '20px';
        
        const saveButton = document.createElement('button');
        saveButton.className = 'btn btn-primary';
        saveButton.textContent = translate('Save Calculation');
        saveButton.addEventListener('click', saveCalculation);
        actionButtons.appendChild(saveButton);
        
        // PDF Export button
        const pdfButton = document.createElement('button');
        pdfButton.className = 'btn btn-success';
        pdfButton.style.marginLeft = '10px';
        pdfButton.textContent = translate('Export as PDF');
        pdfButton.addEventListener('click', exportAsPDF);
        actionButtons.appendChild(pdfButton);
        
        // Excel Export button
        const excelButton = document.createElement('button');
        excelButton.className = 'btn btn-info';
        excelButton.style.marginLeft = '10px';
        excelButton.textContent = translate('Export as Excel');
        excelButton.addEventListener('click', exportAsExcel);
        actionButtons.appendChild(excelButton);
        
        tabContent.appendChild(actionButtons);
        break;

      case 'saved':
        tabContent.appendChild(SavedCalculations(loadSavedCalculations, handleLoadCalculation, handleDeleteCalculation));
        break;
    }
    
    mainContent.appendChild(tabContent);
    appContainer.appendChild(mainContent);
    
    // Render footer
    appContainer.appendChild(Footer());
    
    container.appendChild(appContainer);
    
    // Initialize icons
    if (window.feather) {
      window.feather.replace();
    }
  }
  
  // Event handlers for form changes
  function handleSamplePrepChange(field, value) {
    state.samplePrep[field] = value;
    render();
  }
  
  function handleInstrumentationChange(field, value) {
    state.instrumentation[field] = value;
    render();
  }
  
  function handleReagentChange(reagents) {
    state.reagents = reagents;
    render();
  }
  
  function handleWasteChange(field, value) {
    state.waste[field] = value;
    render();
  }
  
  function handlePracticalityChange(field, value) {
    state.practicality[field] = value;
    render();
  }
  
  // Calculate all scores
  function calculateScores() {
    // Import calculation function and compute scores
    state.scores = calculateTotalEIScore(state.samplePrep, state.instrumentation, state.reagents, state.waste, state.practicality);
    
    // Set color class based on the EI Index score (not total score)
    if (state.scores.eiIndex === 0) {
      state.colorClass = 'result-ideal';
    } else if (state.scores.eiIndex <= 25) {
      state.colorClass = 'result-good';
    } else if (state.scores.eiIndex <= 50) {
      state.colorClass = 'result-medium';
    } else {
      state.colorClass = 'result-bad';
    }
    
    // Set practicality color class based on practicality score
    if (state.scores.practicality >= 75) {
      state.practicalityColorClass = 'practicality-excellent';
    } else if (state.scores.practicality >= 50) {
      state.practicalityColorClass = 'practicality-acceptable';
    } else {
      state.practicalityColorClass = 'practicality-impractical';
    }
  }
  
  // Save current calculation to database
  async function saveCalculation() {
    calculateScores();
    const calculation = {
      date: new Date().toISOString(),
      name: prompt(translate('Enter a name for this calculation:'), translate('Calculation') + ' ' + new Date().toLocaleString()),
      data: {
        samplePrep: { ...state.samplePrep },
        instrumentation: { ...state.instrumentation },
        reagents: [...state.reagents],
        waste: { ...state.waste },
        practicality: { ...state.practicality },
        scores: { ...state.scores }
      }
    };
    
    if (calculation.name) {
      const hideLoader = showLoader(translate('Saving calculation...'));
      
      try {
        await saveToDB(calculation);
        hideLoader();
        
        // Create a chemical reaction animation to indicate success
        const tabContent = document.querySelector('.tab-content');
        if (tabContent) {
          createReactionAnimation(tabContent, () => {
            alert(translate('Calculation saved successfully!'));
          });
        } else {
          alert(translate('Calculation saved successfully!'));
        }
      } catch (error) {
        hideLoader();
        console.error('Error saving calculation:', error);
        alert(translate('Error saving calculation'));
      }
    }
  }
  
  // Load saved calculations
  async function loadSavedCalculations() {
    try {
      return await getCalculations();
    } catch (error) {
      console.error('Error loading calculations:', error);
      return [];
    }
  }
  
  // Load a specific calculation
  async function handleLoadCalculation(id) {
    try {
      const calculation = await getCalculationById(id);
      if (calculation) {
        state.samplePrep = { ...calculation.data.samplePrep };
        state.instrumentation = { ...calculation.data.instrumentation };
        state.reagents = [...calculation.data.reagents];
        state.waste = { ...calculation.data.waste };
        // Handle practicality data for backwards compatibility with older saved calculations
        if (calculation.data.practicality) {
          state.practicality = { ...calculation.data.practicality };
        }
        state.scores = { ...calculation.data.scores };
        calculationId = id;
        currentTab = 'results';
        render();
        
        // Ensure watermark is applied after loading a calculation
        setTimeout(() => {
          const tabContent = document.querySelector('.tab-content');
          if (tabContent) {
            createTabWatermark(tabContent, 'results');
          }
        }, 100);
      }
    } catch (error) {
      console.error('Error loading calculation:', error);
      alert(translate('Error loading calculation'));
    }
  }
  
  // Delete a calculation
  async function handleDeleteCalculation(id) {
    try {
      if (confirm(translate('Are you sure you want to delete this calculation?'))) {
        await deleteCalculation(id);
        render();
      }
    } catch (error) {
      console.error('Error deleting calculation:', error);
      alert(translate('Error deleting calculation'));
    }
  }
  
  // Export results as PDF
  async function exportAsPDF() {
    calculateScores();
    const hideLoader = showLoader(translate('Generating PDF report...'));
    
    try {
      await generatePDF(state);
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert(translate('Error generating PDF file'));
    } finally {
      hideLoader();
    }
  }
  
  // Export results as Excel
  async function exportAsExcel() {
    calculateScores();
    const hideLoader = showLoadingWithFacts(document.body);
    
    try {
      await generateExcel(state);
    } catch (error) {
      console.error('Error generating Excel:', error);
      alert(translate('Error generating Excel file'));
    } finally {
      hideLoader();
    }
  }
  
  // Register event listeners for menu items
  window.api.onMenuSaveCalculation(() => {
    if (currentTab !== 'results') {
      currentTab = 'results';
      render();
    }
    setTimeout(saveCalculation, 100);
  });
  
  window.api.onMenuLoadCalculation(() => {
    currentTab = 'saved';
    render();
  });
  
  window.api.onMenuExportPDF(() => {
    if (currentTab !== 'results') {
      currentTab = 'results';
      render();
    }
    setTimeout(exportAsPDF, 100);
  });
  

  
  window.api.onMenuAbout(() => {
    const modal = document.createElement('div');
    modal.className = 'modal';
    
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-content';
    
    const modalHeader = document.createElement('div');
    modalHeader.className = 'modal-header';
    
    const title = document.createElement('h3');
    title.textContent = 'About EI Scale Calculator';
    
    const closeBtn = document.createElement('button');
    closeBtn.className = 'close-btn';
    closeBtn.innerHTML = '&times;';
    closeBtn.addEventListener('click', () => {
      document.body.removeChild(modal);
    });
    
    modalHeader.appendChild(title);
    modalHeader.appendChild(closeBtn);
    
    const modalBody = document.createElement('div');
    modalBody.innerHTML = `
      <p>The Environmental Impact (EI) Scale Calculator is a tool for assessing both the environmental sustainability and practical applicability of analytical chemistry methods.</p>
      <p>The EI Scale now consists of two main components:</p>
      <h4>EI Index (70% of total score)</h4>
      <ul>
        <li><strong>Sample Preparation</strong>: Evaluates the environmental friendliness and efficiency of sample preparation.</li>
        <li><strong>Instrumentation</strong>: Assesses the sustainability of analytical instruments.</li>
        <li><strong>Reagent</strong>: Evaluates the environmental impact of solvents and chemicals used.</li>
        <li><strong>Waste</strong>: Measures the impact of waste generation and management.</li>
      </ul>
      <p>A lower EI Index score (0-100) reflects a greener and more environmentally sustainable analytical method:</p>
      <ul>
        <li>0: Ideal Green</li>
        <li>1-25: Minimal Impact</li>
        <li>26-50: Considerable Impact</li>
        <li>>50: Serious Impact</li>
      </ul>
      
      <h4>Practicality Index (30% of total score)</h4>
      <p>Evaluates method practicality through nine criteria including method nature, experiment design, validation, sensitivity, and costs.</p>
      <p>A higher Practicality Index score (0-100) indicates better real-world applicability:</p>
      <ul>
        <li>75-100: Excellent</li>
        <li>50-74: Acceptable</li>
        <li>&lt;50: Impractical</li>
      </ul>
      
      <p>Version 2.0.0</p>
    `;
    
    modalContent.appendChild(modalHeader);
    modalContent.appendChild(modalBody);
    modal.appendChild(modalContent);
    
    document.body.appendChild(modal);
  });
  
  // Initial render
  render();
  
  return {
    render
  };
}
