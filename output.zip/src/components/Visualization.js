import { translate } from '../utils/i18n.js';
import { SCORE_COLORS } from '../data/constants.js';

export function Visualization(scores) {
  const visualizationContainer = document.createElement('div');
  visualizationContainer.className = 'form-section card';
  
  const title = document.createElement('h3');
  title.textContent = translate('Visualization');
  visualizationContainer.appendChild(title);
  
  // Create tab navigation for different chart types
  const chartTabs = document.createElement('div');
  chartTabs.className = 'tabs';
  
  // Add tab buttons
  const barChartTab = document.createElement('div');
  barChartTab.className = 'tab active';
  barChartTab.textContent = translate('Bar Chart');
  barChartTab.dataset.chartType = 'bar';
  chartTabs.appendChild(barChartTab);
  
  const radarChartTab = document.createElement('div');
  radarChartTab.className = 'tab';
  radarChartTab.textContent = translate('Radar Chart');
  radarChartTab.dataset.chartType = 'radar';
  chartTabs.appendChild(radarChartTab);
  
  const polarChartTab = document.createElement('div');
  polarChartTab.className = 'tab';
  polarChartTab.textContent = translate('Polar Area Chart');
  polarChartTab.dataset.chartType = 'polarArea';
  chartTabs.appendChild(polarChartTab);
  
  visualizationContainer.appendChild(chartTabs);
  
  // Create a container for each chart type
  const barChartContainer = document.createElement('div');
  barChartContainer.className = 'chart-container active';
  barChartContainer.dataset.chartType = 'bar';
  
  const radarChartContainer = document.createElement('div');
  radarChartContainer.className = 'chart-container';
  radarChartContainer.dataset.chartType = 'radar';
  radarChartContainer.style.display = 'none';
  
  const polarChartContainer = document.createElement('div');
  polarChartContainer.className = 'chart-container';
  polarChartContainer.dataset.chartType = 'polarArea';
  polarChartContainer.style.display = 'none';
  
  // Create canvases for each chart
  const barCanvas = document.createElement('canvas');
  barCanvas.id = 'barChart';
  barChartContainer.appendChild(barCanvas);
  
  const radarCanvas = document.createElement('canvas');
  radarCanvas.id = 'radarChart';
  radarChartContainer.appendChild(radarCanvas);
  
  const polarCanvas = document.createElement('canvas');
  polarCanvas.id = 'polarChart';
  polarChartContainer.appendChild(polarCanvas);
  
  visualizationContainer.appendChild(barChartContainer);
  visualizationContainer.appendChild(radarChartContainer);
  visualizationContainer.appendChild(polarChartContainer);
  
  // Create the score interpretation legend
  const legendContainer = document.createElement('div');
  legendContainer.className = 'legend-container';
  legendContainer.style.marginTop = '20px';
  legendContainer.style.display = 'flex';
  legendContainer.style.justifyContent = 'center';
  legendContainer.style.gap = '10px';
  legendContainer.style.flexWrap = 'wrap';
  
  // Create legend items for each score range
  Object.values(SCORE_COLORS).forEach(colorInfo => {
    const legendItem = document.createElement('div');
    legendItem.className = 'legend-item';
    legendItem.style.display = 'flex';
    legendItem.style.alignItems = 'center';
    legendItem.style.marginRight = '10px';
    
    const colorBox = document.createElement('div');
    colorBox.style.width = '15px';
    colorBox.style.height = '15px';
    colorBox.style.backgroundColor = colorInfo.color;
    colorBox.style.marginRight = '5px';
    
    const label = document.createElement('span');
    label.textContent = `${colorInfo.range[0]}-${colorInfo.range[1]}: ${translate(colorInfo.label)}`;
    
    legendItem.appendChild(colorBox);
    legendItem.appendChild(label);
    legendContainer.appendChild(legendItem);
  });
  
  visualizationContainer.appendChild(legendContainer);
  
  // Total EI score container with visual indicator
  const totalScoreContainer = document.createElement('div');
  totalScoreContainer.className = 'total-score-container';
  totalScoreContainer.style.marginTop = '20px';
  totalScoreContainer.style.textAlign = 'center';
  
  // Get color based on total score
  let totalScoreColor;
  let colorClass;
  
  if (scores.total === 0) {
    totalScoreColor = SCORE_COLORS.IDEAL.color;
    colorClass = SCORE_COLORS.IDEAL.className;
  } else if (scores.total <= 25) {
    totalScoreColor = SCORE_COLORS.GOOD.color;
    colorClass = SCORE_COLORS.GOOD.className;
  } else if (scores.total <= 50) {
    totalScoreColor = SCORE_COLORS.MEDIUM.color;
    colorClass = SCORE_COLORS.MEDIUM.className;
  } else {
    totalScoreColor = SCORE_COLORS.BAD.color;
    colorClass = SCORE_COLORS.BAD.className;
  }
  
  // Total score gauge
  const gaugeContainer = document.createElement('div');
  gaugeContainer.style.position = 'relative';
  gaugeContainer.style.width = '200px';
  gaugeContainer.style.height = '100px';
  gaugeContainer.style.margin = '0 auto';
  
  // Create a gauge-like display
  const gaugeBackground = document.createElement('div');
  gaugeBackground.style.position = 'absolute';
  gaugeBackground.style.width = '100%';
  gaugeBackground.style.height = '20px';
  gaugeBackground.style.backgroundColor = '#e0e0e0';
  gaugeBackground.style.borderRadius = '10px';
  gaugeBackground.style.top = '50%';
  gaugeBackground.style.transform = 'translateY(-50%)';
  
  const gaugeIndicator = document.createElement('div');
  const indicatorWidth = Math.min(100, (scores.total / 100) * 200);
  gaugeIndicator.style.position = 'absolute';
  gaugeIndicator.style.width = `${indicatorWidth}px`;
  gaugeIndicator.style.height = '20px';
  gaugeIndicator.style.backgroundColor = totalScoreColor;
  gaugeIndicator.style.borderRadius = '10px';
  gaugeIndicator.style.top = '50%';
  gaugeIndicator.style.transform = 'translateY(-50%)';
  
  const scoreLabel = document.createElement('div');
  scoreLabel.style.position = 'absolute';
  scoreLabel.style.top = '80%';
  scoreLabel.style.left = '50%';
  scoreLabel.style.transform = 'translateX(-50%)';
  scoreLabel.style.fontWeight = 'bold';
  scoreLabel.style.fontSize = '18px';
  scoreLabel.style.color = totalScoreColor;
  scoreLabel.textContent = `${scores.total.toFixed(1)}`;
  
  gaugeContainer.appendChild(gaugeBackground);
  gaugeContainer.appendChild(gaugeIndicator);
  gaugeContainer.appendChild(scoreLabel);
  
  const scoreInterpretation = document.createElement('div');
  scoreInterpretation.className = `score-interpretation ${colorClass}`;
  scoreInterpretation.style.marginTop = '10px';
  scoreInterpretation.style.padding = '10px';
  scoreInterpretation.style.borderRadius = '5px';
  scoreInterpretation.style.fontWeight = 'bold';
  
  if (scores.total === 0) {
    scoreInterpretation.textContent = translate('No impact - Ideal green analytical method');
  } else if (scores.total <= 25) {
    scoreInterpretation.textContent = translate('Minimal impact - Environmentally friendly and sustainable');
  } else if (scores.total <= 50) {
    scoreInterpretation.textContent = translate('Considerable impact - Method requires improvements for sustainability');
  } else {
    scoreInterpretation.textContent = translate('Serious impact - Unsustainable method needing urgent intervention');
  }
  
  totalScoreContainer.appendChild(gaugeContainer);
  totalScoreContainer.appendChild(scoreInterpretation);
  
  visualizationContainer.appendChild(totalScoreContainer);
  
  // Initialize charts
  setTimeout(() => {
    // Bar chart
    createBarChart(barCanvas, scores);
    
    // Radar chart
    createRadarChart(radarCanvas, scores);
    
    // Polar area chart
    createPolarAreaChart(polarCanvas, scores);
    
    // Add tab switching functionality
    const tabs = chartTabs.querySelectorAll('.tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        // Remove active class from all tabs
        tabs.forEach(t => t.classList.remove('active'));
        
        // Add active class to clicked tab
        tab.classList.add('active');
        
        // Hide all chart containers
        const chartContainers = visualizationContainer.querySelectorAll('.chart-container');
        chartContainers.forEach(container => {
          container.style.display = 'none';
        });
        
        // Show the selected chart container
        const chartType = tab.dataset.chartType;
        const selectedContainer = visualizationContainer.querySelector(`.chart-container[data-chart-type="${chartType}"]`);
        if (selectedContainer) {
          selectedContainer.style.display = 'block';
        }
      });
    });
  }, 0);
  
  return visualizationContainer;
}

function createBarChart(canvas, scores) {
  const ctx = canvas.getContext('2d');
  
  // Determine which components are best and worst
  const componentScores = [
    { name: 'Sample Preparation', value: scores.samplePrep },
    { name: 'Instrumentation', value: scores.instrumentation },
    { name: 'Reagent', value: scores.reagent },
    { name: 'Waste', value: scores.waste }
  ];
  
  // Sort components to find highest and lowest
  const sortedComponents = [...componentScores].sort((a, b) => a.value - b.value);
  const lowestComponent = sortedComponents[0];
  const highestComponent = sortedComponents[sortedComponents.length - 1];
  
  // Component-specific colors - gradient colors based on score value
  const componentColors = componentScores.map(component => {
    // Gradient from red to green based on score value
    if (component.value >= 90) {
      return '#00C853'; // Bright green for excellent scores (90-100)
    } else if (component.value >= 75) {
      return '#64DD17'; // Light green for good scores (75-89)
    } else if (component.value >= 60) {
      return '#AEEA00'; // Lime green for above average scores (60-74)
    } else if (component.value >= 50) {
      return '#FFD600'; // Amber for acceptable scores (50-59)
    } else if (component.value >= 40) {
      return '#FFAB00'; // Orange for concerning scores (40-49)
    } else if (component.value >= 25) {
      return '#FF6D00'; // Deep orange for poor scores (25-39)
    } else {
      return '#DD2C00'; // Red for very poor scores (0-24)
    }
  });
  
  // Create the chart
  const chart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: componentScores.map(c => c.name),
      datasets: [{
        label: translate('EI Component Scores'),
        data: componentScores.map(c => c.value),
        backgroundColor: componentColors,
        borderColor: componentColors,
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: translate('Component Scores Comparison'),
          font: {
            size: 18,
            weight: 'bold'
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return `${context.label}: ${context.raw.toFixed(1)}`;
            }
          }
        }
      },
      scales: {
        y: {
          beginAtZero: true,
          max: 100,
          title: {
            display: true,
            text: translate('Score (0-100)'),
            font: {
              weight: 'bold'
            }
          },
          grid: {
            color: 'rgba(200, 200, 200, 0.2)'
          }
        },
        x: {
          title: {
            display: false
          },
          grid: {
            display: false
          }
        }
      }
    }
  });
  
  return chart;
}

function createRadarChart(canvas, scores) {
  const ctx = canvas.getContext('2d');
  
  // Component-specific colors for better visual distinction
  const componentColors = [
    'rgba(33, 150, 243, 0.7)',    // Blue for Sample Prep
    'rgba(156, 39, 176, 0.7)',    // Purple for Instrumentation
    'rgba(255, 152, 0, 0.7)',     // Orange for Reagent
    'rgba(76, 175, 80, 0.7)'      // Green for Waste
  ];
  
  const componentBorderColors = componentColors.map(color => color.replace('0.7', '1'));
  
  // Create the chart
  const chart = new Chart(ctx, {
    type: 'radar',
    data: {
      labels: [
        translate('Sample Preparation'), 
        translate('Instrumentation'), 
        translate('Reagent'), 
        translate('Waste')
      ],
      datasets: [{
        label: translate('Component Scores'),
        data: [
          scores.samplePrep,
          scores.instrumentation,
          scores.reagent,
          scores.waste
        ],
        backgroundColor: 'rgba(54, 162, 235, 0.2)',
        borderColor: 'rgba(54, 162, 235, 0.8)',
        borderWidth: 2,
        pointBackgroundColor: componentColors,
        pointBorderColor: componentBorderColors,
        pointHoverBackgroundColor: '#fff',
        pointHoverBorderColor: componentBorderColors,
        pointRadius: 5,
        pointHoverRadius: 7
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        r: {
          beginAtZero: true,
          max: 100,
          ticks: {
            stepSize: 20
          }
        }
      },
      plugins: {
        title: {
          display: true,
          text: translate('Environmental Impact Radar'),
          font: {
            size: 16
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return `${context.label}: ${context.raw.toFixed(1)}`;
            }
          }
        }
      }
    }
  });
  
  return chart;
}

function createPolarAreaChart(canvas, scores) {
  const ctx = canvas.getContext('2d');
  
  // Component-specific colors with improved vibrancy and contrast
  const componentColors = [
    'rgba(33, 150, 243, 0.8)',   // Bright blue for Sample Prep
    'rgba(156, 39, 176, 0.8)',   // Deep purple for Instrumentation
    'rgba(255, 152, 0, 0.8)',    // Vibrant orange for Reagent
    'rgba(76, 175, 80, 0.8)'     // Rich green for Waste
  ];
  
  // Create the chart
  const chart = new Chart(ctx, {
    type: 'polarArea',
    data: {
      labels: [
        translate('Sample Preparation'), 
        translate('Instrumentation'), 
        translate('Reagent'), 
        translate('Waste')
      ],
      datasets: [{
        data: [
          scores.samplePrep,
          scores.instrumentation,
          scores.reagent,
          scores.waste
        ],
        backgroundColor: componentColors,
        borderColor: componentColors.map(color => color.replace('0.8', '1')),
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        r: {
          beginAtZero: true,
          max: 100,
          ticks: {
            stepSize: 20
          }
        }
      },
      plugins: {
        title: {
          display: true,
          text: translate('EI Component Distribution'),
          font: {
            size: 16
          }
        },
        tooltip: {
          callbacks: {
            label: function(context) {
              return `${context.label}: ${context.raw.toFixed(1)}`;
            }
          }
        }
      }
    }
  });
  
  return chart;
}
