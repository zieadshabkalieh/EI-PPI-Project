import { getCurrentLanguage, setLanguage, languageNames } from '../utils/i18n.js';

export function LanguageSelector() {
  const container = document.createElement('div');
  container.className = 'language-selector';
  
  // Create a select element for language selection
  const select = document.createElement('select');
  select.className = 'language-select';
  
  // Populate options for all available languages
  Object.keys(languageNames).forEach(langCode => {
    const option = document.createElement('option');
    option.value = langCode;
    option.textContent = languageNames[langCode];
    option.selected = langCode === getCurrentLanguage();
    select.appendChild(option);
  });
  
  // Add event listener for language change
  select.addEventListener('change', (e) => {
    const newLanguage = e.target.value;
    setLanguage(newLanguage);
    // Reload the page to apply the new language
    window.location.reload();
  });
  
  // Add a label
  const label = document.createElement('span');
  label.className = 'language-label';
  label.textContent = '🌐';
  
  // Append elements to container
  container.appendChild(label);
  container.appendChild(select);
  
  return container;
}