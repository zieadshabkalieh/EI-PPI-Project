import { translate } from '../../utils/i18n.js';

export function PracticalityForm(state, onChange) {
  const form = document.createElement('div');
  form.className = 'form-section card practicality-card';
  
  const title = document.createElement('h3');
  title.textContent = translate('Practicality Index');
  form.appendChild(title);
  
  // Info card with detailed explanation
  const infoCard = document.createElement('div');
  infoCard.className = 'info-card info-card-practicality';
  
  const infoCardTitle = document.createElement('div');
  infoCardTitle.className = 'info-card-title';
  infoCardTitle.textContent = translate('About Practicality Index');
  infoCard.appendChild(infoCardTitle);
  
  const infoCardContent = document.createElement('div');
  infoCardContent.className = 'info-card-content';
  infoCardContent.innerHTML = `
    <p>${translate('The Practicality Index (PI) accounts for 30% of the total EI Scale. It measures the real-world applicability and efficiency of an analytical method.')}</p>
    <p>${translate('Please fill in the information below to calculate your Practicality Index (PI).')}</p>
  `;
  infoCard.appendChild(infoCardContent);
  form.appendChild(infoCard);
  
  // 1. Nature of Method
  const natureGroup = createFormGroup(
    translate('Nature of Method'),
    'natureOfMethod',
    [
      { value: 'quantitative', label: translate('Quantitative'), score: '10' },
      { value: 'qualitative', label: translate('Qualitative'), score: '5' }
    ],
    state.natureOfMethod || 'quantitative',
    (value) => onChange('natureOfMethod', value)
  );
  natureGroup.classList.add('practicality-option');
  form.appendChild(natureGroup);
  
  // 2. Design of Experiment
  const designGroup = createFormGroup(
    translate('Design of Experiment'),
    'designOfExperiment',
    [
      { value: 'factorial', label: translate('Factorial'), score: '10' },
      { value: 'ofat', label: translate('OFAT (One Factor At a Time)'), score: '5' },
      { value: 'none', label: translate('None'), score: '0' }
    ],
    state.designOfExperiment || 'factorial',
    (value) => onChange('designOfExperiment', value)
  );
  designGroup.classList.add('practicality-option');
  form.appendChild(designGroup);
  
  // 3. Validation
  const validationGroup = createFormGroup(
    translate('Validation'),
    'validation',
    [
      { value: 'full', label: translate('Fully Validated'), score: '25' },
      { value: 'partial', label: translate('Partial'), score: '10' },
      { value: 'none', label: translate('Not validated'), score: '0' }
    ],
    state.validation || 'full',
    (value) => onChange('validation', value)
  );
  validationGroup.classList.add('practicality-option');
  form.appendChild(validationGroup);
  
  // 4. Sensitivity
  const sensitivityGroup = createFormGroup(
    translate('Sensitivity'),
    'sensitivity',
    [
      { value: 'picogram', label: translate('Picogram'), score: '10' },
      { value: 'nanogram', label: translate('Nanogram'), score: '8' },
      { value: 'microgram', label: translate('Microgram'), score: '5' },
      { value: 'more', label: translate('>Microgram'), score: '2' }
    ],
    state.sensitivity || 'picogram',
    (value) => onChange('sensitivity', value)
  );
  sensitivityGroup.classList.add('practicality-option');
  form.appendChild(sensitivityGroup);
  
  // 5. Cost of Reagents
  const reagentCostGroup = createFormGroup(
    translate('Cost of Reagents'),
    'reagentCost',
    [
      { value: 'low', label: translate('Low'), score: '8' },
      { value: 'moderate', label: translate('Moderate'), score: '5' },
      { value: 'high', label: translate('High'), score: '2' }
    ],
    state.reagentCost || 'low',
    (value) => onChange('reagentCost', value)
  );
  reagentCostGroup.classList.add('practicality-option');
  form.appendChild(reagentCostGroup);
  
  // 6. Cost of Instrument
  const instrumentCostGroup = createFormGroup(
    translate('Cost of Instrument'),
    'instrumentCost',
    [
      { value: 'low', label: translate('Low'), score: '8' },
      { value: 'high', label: translate('High'), score: '4' }
    ],
    state.instrumentCost || 'low',
    (value) => onChange('instrumentCost', value)
  );
  instrumentCostGroup.classList.add('practicality-option');
  form.appendChild(instrumentCostGroup);
  
  // 7. Maintenance frequency and instrument lifetime
  const maintenanceGroup = createFormGroup(
    translate('Maintenance frequency and instrument lifetime'),
    'maintenance',
    [
      { value: 'long', label: translate('Long lifespans and minimal maintenance'), score: '10' },
      { value: 'frequent', label: translate('Frequent repairs or replacement'), score: '5' }
    ],
    state.maintenance || 'long',
    (value) => onChange('maintenance', value)
  );
  maintenanceGroup.classList.add('practicality-option');
  form.appendChild(maintenanceGroup);
  
  // 8. Time of Analysis (Throughput)
  const throughputGroup = createFormGroup(
    translate('Time of Analysis (Throughput)'),
    'throughput',
    [
      { value: 'high', label: translate('≥25 samples/hr'), score: '9' },
      { value: 'low', label: translate('≤10 samples/hr'), score: '4' }
    ],
    state.throughput || 'high',
    (value) => onChange('throughput', value)
  );
  throughputGroup.classList.add('practicality-option');
  form.appendChild(throughputGroup);
  
  // 9. Sample Reusability
  const reusabilityGroup = createFormGroup(
    translate('Sample Reusability'),
    'reusability',
    [
      { value: 'yes', label: translate('Yes'), score: '10' },
      { value: 'no', label: translate('No'), score: '0' }
    ],
    state.reusability || 'yes',
    (value) => onChange('reusability', value)
  );
  reusabilityGroup.classList.add('practicality-option');
  form.appendChild(reusabilityGroup);
  
  // Practicality Index criteria table
  const criteriaTable = document.createElement('div');
  criteriaTable.className = 'practicality-criteria-table';
  criteriaTable.style.marginTop = '30px';
  criteriaTable.style.marginBottom = '20px';
  
  const criteriaTitle = document.createElement('h4');
  criteriaTitle.textContent = translate('Criteria and Scoring Scheme for the Practicality Index (PI)');
  criteriaTitle.style.textAlign = 'center';
  criteriaTitle.style.marginBottom = '15px';
  criteriaTable.appendChild(criteriaTitle);
  
  const table = document.createElement('table');
  table.className = 'criteria-table';
  table.innerHTML = `
    <thead>
      <tr>
        <th>${translate('S. No')}</th>
        <th>${translate('Criteria')}</th>
        <th>${translate('Scoring Options')}</th>
        <th>${translate('Max Score')}</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>${translate('Nature of Method')}</td>
        <td>${translate('Quantitative (10), Qualitative (5)')}</td>
        <td>10</td>
      </tr>
      <tr>
        <td>2</td>
        <td>${translate('Design of Experiment')}</td>
        <td>${translate('Factorial (10), OFAT (5), None (0)')}</td>
        <td>10</td>
      </tr>
      <tr>
        <td>3</td>
        <td>${translate('Validation')}</td>
        <td>${translate('Fully Validated (25), Partial (10), Not validated (0)')}</td>
        <td>25</td>
      </tr>
      <tr>
        <td>4</td>
        <td>${translate('Sensitivity')}</td>
        <td>${translate('Picogram (10), Nanogram (8), Microgram (5), >Microgram (2)')}</td>
        <td>10</td>
      </tr>
      <tr>
        <td>5</td>
        <td>${translate('Cost of Reagents')}</td>
        <td>${translate('Low (8), Moderate (5), High (2)')}</td>
        <td>8</td>
      </tr>
      <tr>
        <td>6</td>
        <td>${translate('Cost of Instrument')}</td>
        <td>${translate('Low (8), High (4)')}</td>
        <td>8</td>
      </tr>
      <tr>
        <td>7</td>
        <td>${translate('Maintenance frequency and instrument lifetime')}</td>
        <td>${translate('Long lifespans and minimal maintenance (10), Frequent repairs or replacement (5)')}</td>
        <td>10</td>
      </tr>
      <tr>
        <td>8</td>
        <td>${translate('Time of Analysis (Throughput)')}</td>
        <td>${translate('≥25 samples/hr (9), ≤10 samples/hr (4)')}</td>
        <td>9</td>
      </tr>
      <tr>
        <td>9</td>
        <td>${translate('Sample Reusability')}</td>
        <td>${translate('Yes (10), No (0)')}</td>
        <td>10</td>
      </tr>
      <tr>
        <td colspan="3" style="text-align: right; font-weight: bold;">${translate('Total')}</td>
        <td style="font-weight: bold;">100</td>
      </tr>
    </tbody>
  `;
  
  criteriaTable.appendChild(table);
  form.appendChild(criteriaTable);
  
  // Add formula note
  const formulaNote = document.createElement('div');
  formulaNote.className = 'formula-note';
  formulaNote.style.marginTop = '20px';
  formulaNote.style.padding = '15px';
  formulaNote.style.backgroundColor = '#f0f8ff';
  formulaNote.style.borderLeft = '4px solid var(--practicality-color)';
  formulaNote.style.borderRadius = '8px';
  formulaNote.style.boxShadow = '0 2px 5px rgba(0,0,0,0.05)';
  formulaNote.innerHTML = translate('The Practicality Index (PI) is calculated as the sum of all scores. A higher score indicates better practicality and real-world applicability of the analytical method. The maximum possible score is 100.');
  form.appendChild(formulaNote);
  
  return form;
}

function createFormGroup(label, name, options, selectedValue, onChange) {
  const group = document.createElement('div');
  group.className = 'form-group';
  
  const groupLabel = document.createElement('label');
  groupLabel.textContent = label;
  groupLabel.htmlFor = name;
  groupLabel.style.fontSize = '1.2rem';
  groupLabel.style.fontWeight = '600';
  groupLabel.style.marginBottom = '15px';
  groupLabel.style.display = 'block';
  group.appendChild(groupLabel);
  
  options.forEach((option, index) => {
    // Create custom radio container
    const radioContainer = document.createElement('label');
    radioContainer.className = 'custom-radio-container';
    radioContainer.htmlFor = `${name}_${option.value}`;
    
    // Create actual radio input (hidden)
    const radio = document.createElement('input');
    radio.className = 'custom-radio-input';
    radio.type = 'radio';
    radio.id = `${name}_${option.value}`;
    radio.name = name;
    radio.value = option.value;
    radio.checked = selectedValue === option.value;
    radio.addEventListener('change', () => onChange(option.value));
    
    // Create custom radio visual element
    const radioCheckmark = document.createElement('span');
    radioCheckmark.className = 'radio-checkmark';
    
    // Create label text
    const labelText = document.createTextNode(option.label);
    
    // Create score display
    const scoreSpan = document.createElement('span');
    scoreSpan.className = 'option-score';
    scoreSpan.textContent = option.score;
    
    // Append all elements
    radioContainer.appendChild(radio);
    radioContainer.appendChild(radioCheckmark);
    radioContainer.appendChild(labelText);
    radioContainer.appendChild(scoreSpan);
    
    group.appendChild(radioContainer);
  });
  
  return group;
}