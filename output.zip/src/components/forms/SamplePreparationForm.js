import { translate } from '../../utils/i18n.js';

export function SamplePreparationForm(state, onChange) {
  const form = document.createElement('div');
  form.className = 'form-section card sample-prep-card';
  
  const title = document.createElement('h3');
  title.textContent = translate('Sample Preparation');
  form.appendChild(title);
  
  // Info card with detailed explanation
  const infoCard = document.createElement('div');
  infoCard.className = 'info-card info-card-sample-prep';
  
  const infoCardTitle = document.createElement('div');
  infoCardTitle.className = 'info-card-title';
  infoCardTitle.textContent = translate('About Sample Preparation');
  infoCard.appendChild(infoCardTitle);
  
  const infoCardContent = document.createElement('div');
  infoCardContent.className = 'info-card-content';
  infoCardContent.innerHTML = `
    <p>${translate('This section helps you calculate the Sample Preparation Score for your analytical method. Sample preparation is a critical step in environmental impact assessment, as it often involves chemicals, energy, and resources.')}</p>
    <ol>
      <li>${translate('Pre-synthesis - Any chemical preparation before the actual analysis')}</li>
      <li>${translate('Sampling requirements - Type and complexity of sampling needed')}</li>
      <li>${translate('Sample type - Complexity and nature of the sample')}</li>
      <li>${translate('Sample throughput - Number of samples processed per day')}</li>
      <li>${translate('Extraction procedure - Methods used to extract analytes')}</li>
      <li>${translate('Other conditions - Additional factors affecting environmental impact')}</li>
    </ol>
    <p>${translate('Please fill in the information below to calculate your Sample Preparation Score.')}</p>
  `;
  infoCard.appendChild(infoCardContent);
  form.appendChild(infoCard);
  
  // Pre-synthesis
  const preSynthesisGroup = createFormGroup(
    translate('Pre-synthesis'),
    'preSynthesis',
    [
      { value: 'no', label: translate('No pre-synthesis required (100)'), score: '100' },
      { value: 'yes', label: translate('Pre-synthesis required (75)'), score: '75' }
    ],
    state.preSynthesis || 'no',
    (value) => onChange('preSynthesis', value)
  );
  form.appendChild(preSynthesisGroup);
  
  // Show additional options if pre-synthesis is required
  if (state.preSynthesis === 'yes') {
    // Yield
    const yieldGroup = createFormGroup(
      translate('Yield'),
      'yield',
      [
        { value: 'high', label: translate('High yield >90% (5)'), score: '5' },
        { value: 'moderate', label: translate('Moderate yield 50-90% (0)'), score: '0' },
        { value: 'low', label: translate('Low yield <50% (-5)'), score: '-5' }
      ],
      state.yield || 'high',
      (value) => onChange('yield', value)
    );
    yieldGroup.style.marginLeft = '15px';
    form.appendChild(yieldGroup);
    
    // Temperature
    const temperatureGroup = createFormGroup(
      translate('Temperature'),
      'temperature',
      [
        { value: 'high', label: translate('High temp. for more than 1 hr or cooling less than 0°C (-10)'), score: '-10' },
        { value: 'room', label: translate('Room temperature more than 1 hr or heating less than 1 hr or cooling less than 0°C (-5)'), score: '-5' }
      ],
      state.temperature || 'room',
      (value) => onChange('temperature', value)
    );
    temperatureGroup.style.marginLeft = '15px';
    form.appendChild(temperatureGroup);
    
    // Purification needed
    const purificationGroup = createFormGroup(
      translate('Purification needed'),
      'purification',
      [
        { value: 'yes', label: translate('Yes (-5)'), score: '-5' },
        { value: 'no', label: translate('No (5)'), score: '5' }
      ],
      state.purification === true ? 'yes' : 'no',
      (value) => onChange('purification', value === 'yes')
    );
    purificationGroup.style.marginLeft = '15px';
    form.appendChild(purificationGroup);
    
    // High energy consumption equipment
    const energyGroup = createFormGroup(
      translate('High energy consumption equipment >1.5 kW per sample'),
      'energyConsumption',
      [
        { value: 'yes', label: translate('Yes (-5)'), score: '-5' },
        { value: 'no', label: translate('No (5)'), score: '5' }
      ],
      state.energyConsumption === true ? 'yes' : 'no',
      (value) => onChange('energyConsumption', value === 'yes')
    );
    energyGroup.style.marginLeft = '15px';
    form.appendChild(energyGroup);
    
    // Use of non green solvent
    const solventGroup = createFormGroup(
      translate('Use of non green solvent'),
      'nonGreenSolvent',
      [
        { value: 'yes', label: translate('Yes (-5)'), score: '-5' },
        { value: 'no', label: translate('No (5)'), score: '5' }
      ],
      state.nonGreenSolvent === true ? 'yes' : 'no',
      (value) => onChange('nonGreenSolvent', value === 'yes')
    );
    solventGroup.style.marginLeft = '15px';
    form.appendChild(solventGroup);
    
    // Presence of occupational hazard
    const hazardGroup = createFormGroup(
      translate('Presence of occupational hazard'),
      'occupationalHazard',
      [
        { value: 'yes', label: translate('Yes (-5)'), score: '-5' },
        { value: 'no', label: translate('No (5)'), score: '5' }
      ],
      state.occupationalHazard === true ? 'yes' : 'no',
      (value) => onChange('occupationalHazard', value === 'yes')
    );
    hazardGroup.style.marginLeft = '15px';
    form.appendChild(hazardGroup);
  }
  
  // Sampling required
  const instrumentRequirementsGroup = createFormGroup(
    translate('Sampling required'),
    'instrumentRequirements',
    [
      { value: 'none', label: translate('No sample preparation required ATR technique or direct analysis (100)'), score: '100' },
      { value: 'minimal', label: translate('Minimal sample preparation as in UV spectroscopy (Dilution) (90)'), score: '90' },
      { value: 'moderate', label: translate('Moderate sample preparation HPLC (Filtration or sonication) (80)'), score: '80' },
      { value: 'high', label: translate('High sample preparations (Bio-analytical) (70)'), score: '70' }
    ],
    state.instrumentRequirements || 'none',
    (value) => onChange('instrumentRequirements', value)
  );
  form.appendChild(instrumentRequirementsGroup);
  
  // Type of sample and sample efficiency
  const sampleTypeGroup = createFormGroup(
    translate('Type of sample and sample efficiency'),
    'sampleType',
    [
      { value: 'simple', label: translate('Simple procedure (e.g., for pharmaceutical dosage forms) (100)'), score: '100' },
      { value: 'extensive', label: translate('Extensive preparation (e.g., for biological, food, or environmental samples) (50)'), score: '50' }
    ],
    state.sampleType || 'simple',
    (value) => onChange('sampleType', value)
  );
  
  // Add detailed description for sample types
  const sampleTypeHelpText = document.createElement('div');
  sampleTypeHelpText.className = 'help-text';
  sampleTypeHelpText.style.marginTop = '5px';
  sampleTypeHelpText.style.marginBottom = '15px';
  sampleTypeHelpText.style.paddingLeft = '20px';
  sampleTypeHelpText.innerHTML = `
    <p><em>${translate('Note:')}</em> ${translate('A score of 100 is given for simple procedures required for samples such as pharmaceutical dosage forms, while extensive preparation required for biological, food, and environmental matrices scores 50. These are examples of sample types, not limited to these specific samples.')}</p>
  `;
  sampleTypeGroup.appendChild(sampleTypeHelpText);
  
  form.appendChild(sampleTypeGroup);
  
  // Sample throughput
  const throughputGroup = createFormGroup(
    translate('Sample throughput'),
    'sampleThroughput',
    [
      { value: 'high', label: translate('High sample throughput (≥60 samples/day) (100)'), score: '100' },
      { value: 'moderate', label: translate('Moderate sample throughput (30–59 samples/day) (50)'), score: '50' },
      { value: 'low', label: translate('Low sample throughput (<30 samples/day) (25)'), score: '25' }
    ],
    state.sampleThroughput || 'high',
    (value) => onChange('sampleThroughput', value)
  );
  form.appendChild(throughputGroup);
  
  // Extraction procedure
  const extractionGroup = createFormGroup(
    translate('Extraction procedure'),
    'extractionNeeded',
    [
      { value: 'no', label: translate('No extraction needed (100)'), score: '100' },
      { value: 'yes', label: translate('Extraction needed (60)'), score: '60' }
    ],
    state.extractionNeeded || 'no',
    (value) => onChange('extractionNeeded', value)
  );
  form.appendChild(extractionGroup);
  
  // Show extraction details if extraction is needed
  if (state.extractionNeeded === 'yes') {
    // Solvent Type
    const solventTypeGroup = createFormGroup(
      translate('Solvent Type'),
      'solventType',
      [
        { value: 'complete', label: translate('Complete green solvents (e.g., water, supercritical fluids, deep eutectic solvents, etc.) (10)'), score: '10' },
        { value: 'partial', label: translate('Partial green solvents (5)'), score: '5' },
        { value: 'nongreen', label: translate('Non-greener (conventional organic) solvents (-10)'), score: '-10' }
      ],
      state.solventType || 'complete',
      (value) => onChange('solventType', value)
    );
    solventTypeGroup.style.marginLeft = '15px';
    form.appendChild(solventTypeGroup);
    
    // Solvent Volume
    const solventVolumeGroup = createFormGroup(
      translate('Solvent Volume'),
      'solventVolume',
      [
        { value: 'less1', label: translate('Less than 1 mL (20)'), score: '20' },
        { value: '1to10', label: translate('1 to 10 mL (10)'), score: '10' },
        { value: '10to100', label: translate('10 to 100 mL (5)'), score: '5' },
        { value: 'more100', label: translate('More than 100 mL (-20)'), score: '-20' }
      ],
      state.solventVolume || 'less1',
      (value) => onChange('solventVolume', value)
    );
    solventVolumeGroup.style.marginLeft = '15px';
    form.appendChild(solventVolumeGroup);
    
    // Solid phase used
    const solidPhaseGroup = createFormGroup(
      translate('Solid phase used'),
      'solidPhase',
      [
        { value: 'onetime', label: translate('One time usable (-10)'), score: '-10' },
        { value: 'reusable', label: translate('Reusable (10)'), score: '10' },
        { value: 'na', label: translate('NA (0)'), score: '0' }
      ],
      state.solidPhase || 'na',
      (value) => onChange('solidPhase', value)
    );
    solidPhaseGroup.style.marginLeft = '15px';
    form.appendChild(solidPhaseGroup);
  }
  
  // Other conditions section header
  const otherConditionsHeader = document.createElement('h4');
  otherConditionsHeader.textContent = translate('Other conditions');
  otherConditionsHeader.style.marginTop = '20px';
  form.appendChild(otherConditionsHeader);
  
  // Sampling Requires Derivatization/Digestion
  const derivatizationGroup = createFormGroup(
    translate('Sampling Requires Derivatization/Digestion or extra steps'),
    'derivatization',
    [
      { value: 'yes', label: translate('Yes (-10)'), score: '-10' },
      { value: 'no', label: translate('No or Not Available (0)'), score: '0' }
    ],
    state.derivatization ? 'yes' : 'no',
    (value) => onChange('derivatization', value === 'yes')
  );
  form.appendChild(derivatizationGroup);
  
  // Automated sample preparation
  const automatedPrepGroup = createFormGroup(
    translate('Automated sample preparation'),
    'automatedPreparation',
    [
      { value: 'yes', label: translate('Yes (10)'), score: '10' },
      { value: 'no', label: translate('No or Not Available (0)'), score: '0' }
    ],
    state.automatedPreparation ? 'yes' : 'no',
    (value) => onChange('automatedPreparation', value === 'yes')
  );
  form.appendChild(automatedPrepGroup);
  
  // Type of Sample Preparation
  const preparationTypeGroup = createFormGroup(
    translate('Type of Sample Preparation'),
    'inSituPreparation',
    [
      { value: 'insitu', label: translate('In situ sample preparation (10)'), score: '10' },
      { value: 'offline', label: translate('Offline (-10)'), score: '-10' }
    ],
    state.inSituPreparation ? 'insitu' : (state.offLine ? 'offline' : 'insitu'),
    (value) => {
      onChange('inSituPreparation', value === 'insitu');
      onChange('offLine', value === 'offline');
    }
  );
  form.appendChild(preparationTypeGroup);
  
  // Add formula note
  const formulaNote = document.createElement('div');
  formulaNote.className = 'formula-note';
  formulaNote.style.marginTop = '20px';
  formulaNote.style.padding = '15px';
  formulaNote.style.backgroundColor = '#f0f8ff';
  formulaNote.style.borderLeft = '4px solid var(--sample-prep-color)';
  formulaNote.style.borderRadius = '8px';
  formulaNote.style.boxShadow = '0 2px 5px rgba(0,0,0,0.05)';
  formulaNote.innerHTML = translate('The sample preparation score is calculated by evaluating core factors like pre-synthesis, extraction requirements, sample complexity, and throughput, along with adjustments for automation and specialized procedures. The overall score should not exceed 100.');
  form.appendChild(formulaNote);
  
  return form;
}

function createFormGroup(label, name, options, selectedValue, onChange) {
  const group = document.createElement('div');
  group.className = 'form-group';
  
  const groupLabel = document.createElement('label');
  groupLabel.textContent = label;
  groupLabel.htmlFor = name;
  groupLabel.style.fontSize = '1.2rem';
  groupLabel.style.fontWeight = '600';
  groupLabel.style.marginBottom = '15px';
  groupLabel.style.display = 'block';
  group.appendChild(groupLabel);
  
  options.forEach((option, index) => {
    // Create a container div for the entire option
    const optionContainer = document.createElement('div');
    optionContainer.className = 'radio-option sample-prep-option';
    if (selectedValue === option.value) {
      optionContainer.classList.add('selected');
    }
    
    // Create custom radio container
    const radioContainer = document.createElement('label');
    radioContainer.className = 'custom-radio-container';
    radioContainer.htmlFor = `${name}_${option.value}`;
    
    // Create actual radio input (hidden)
    const radio = document.createElement('input');
    radio.className = 'custom-radio-input';
    radio.type = 'radio';
    radio.id = `${name}_${option.value}`;
    radio.name = name;
    radio.value = option.value;
    radio.checked = selectedValue === option.value;
    radio.addEventListener('change', () => {
      onChange(option.value);
      
      // Update selected class on change
      const options = group.querySelectorAll('.radio-option');
      options.forEach(opt => opt.classList.remove('selected'));
      optionContainer.classList.add('selected');
    });
    
    // Create custom radio visual element
    const radioCheckmark = document.createElement('span');
    radioCheckmark.className = 'radio-checkmark';
    
    // Create label content
    const labelContent = document.createElement('span');
    labelContent.className = 'radio-label-content';
    labelContent.textContent = option.label;
    
    // Create score display
    const scoreSpan = document.createElement('span');
    scoreSpan.className = 'option-score';
    scoreSpan.textContent = option.score;
    
    // Append all elements
    radioContainer.appendChild(radio);
    radioContainer.appendChild(radioCheckmark);
    radioContainer.appendChild(labelContent);
    radioContainer.appendChild(scoreSpan);
    
    // Add the radio container to the option container
    optionContainer.appendChild(radioContainer);
    
    // Add to form group
    group.appendChild(optionContainer);
  });
  
  return group;
}
